"""
intune-flex-deploy 共用模組
用途：Intune 打包（intune_flex_packager.py）、PsExec 直接遠端部署
     （psexec_mass_deploy.py）、網頁介面（ui_server.py）都要「下載 FRD 套件」
     「產生 agent.toml/wifi.onc」，這些抽成共用函式，避免各寫一份、
     之後改規格要改好幾處。

規格來源見兩支主程式開頭的說明。

【給後續維護者的兩個設計重點】
1. 所有會輸出訊息的函式都收一個 log 回呼（預設就是 print）。命令列直接用預設值，
   網頁介面則傳自己的函式進來，把每一行塞進佇列即時推給瀏覽器。
2. 失敗一律 raise FrdError，不用 sys.exit。命令列端接住印出來就好，
   網頁介面端才不會被 sys.exit 連伺服器一起殺掉。
"""

import json
import shutil
import sys
import urllib.request
import uuid
import zipfile
from pathlib import Path

# 打包成 PyInstaller exe 之後 __file__ 會指到暫存解壓資料夾裡，不是使用者放
# ui/、secrets/、templates/ 這些資料夾的地方；要改看執行檔本身在哪。
# 沒打包（直接跑 .py）就維持原本行為，用這支檔案所在的資料夾。
if getattr(sys, "frozen", False):
    PROJECT_DIR = Path(sys.executable).parent
else:
    PROJECT_DIR = Path(__file__).parent
TOOLS_DIR = PROJECT_DIR / "tools"
TEMPLATES_DIR = PROJECT_DIR / "templates"

FRD_PACKAGE_URL = "https://dl.google.com/cros-frd/frd-latest.zip"
FRD_ZIP_PATH = TOOLS_DIR / "frd-latest.zip"
FRD_EXTRACT_DIR = TOOLS_DIR / "frd-package"

# Vector 是官方 samples/deployment.ps1 指定的記錄器：agent.exe 只把記錄吐到 stdout，
# 遠端部署沒有主控台可看，要靠 Vector 落地成 agent.log 才能事後排查。
# 版本跟著官方腳本寫死，之後要換版看 https://vector.dev/download/
VECTOR_URL = (
    "https://packages.timber.io/vector/0.47.0/"
    "vector-0.47.0-x86_64-pc-windows-msvc.zip"
)
VECTOR_ZIP_PATH = TOOLS_DIR / "vector.zip"
VECTOR_EXTRACT_DIR = TOOLS_DIR / "vector"


class FrdError(Exception):
    """流程走不下去時拋這個。命令列接住印出來，網頁介面接住顯示在記錄區，
    兩邊都不會因此整個程序結束。"""


def resolve_download_url(config: dict, kind: str) -> tuple[str, str]:
    """依設定決定要從哪裡下載，回傳（網址, 來源名稱）。kind 是 'frd' 或 'vector'。

    刻意做成「員工在介面上明確選一個」而不是「先試 A 失敗自動換 B」：
    選公司鏡像的理由通常是版本鎖定，如果失敗時偷偷換成官方最新版，
    等於拿到的根本不是想要的版本，比直接報錯還糟。
    """
    official = FRD_PACKAGE_URL if kind == "frd" else VECTOR_URL
    if config.get("download_source") != "r2":
        return official, "Google 官方"

    base = str(config.get("r2_mirror_base_url", "")).strip().rstrip("/")
    if not base:
        raise FrdError(
            "下載來源選了「公司鏡像」，但還沒設定鏡像網址。\n"
            "請先建立鏡像（python mirror_to_r2.py），或改選「Google 官方」。"
        )
    filename = "frd-current.zip" if kind == "frd" else "vector-current.zip"
    return f"{base}/{filename}", "公司鏡像"


def download_file(url: str, dest: Path, log=print) -> None:
    """下載檔案並回報進度。

    一定要帶瀏覽器 User-Agent：Vector 的 CDN 會擋掉 Python-urllib 預設的 UA 直接回
    403（2026-09-10 實測踩到），dl.google.com 則不擋，統一帶著比較保險。

    分塊讀取而不是一次 copyfileobj 到底，是為了能回報百分比 —— FRD 套件將近 1GB，
    沒有進度回報的話介面看起來就像當掉了。
    """
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req) as resp, dest.open("wb") as f:
        total = int(resp.headers.get("Content-Length") or 0)
        done = 0
        last_reported = -1
        while True:
            chunk = resp.read(1024 * 256)
            if not chunk:
                break
            f.write(chunk)
            done += len(chunk)
            if total:
                percent = done * 100 // total
                # 每 5% 回報一次就好，不然記錄區會被洗版
                if percent >= last_reported + 5:
                    last_reported = percent
                    log(f"[下載] {percent}%（{done // 1048576} / {total // 1048576} MB）")
    log(f"[下載] 完成，共 {done // 1048576} MB")


def load_config(config_path: Path) -> dict:
    if not config_path.exists():
        raise FrdError(
            f"找不到設定檔：{config_path}\n"
            f"先複製 secrets\\config.example.json 成 secrets\\config.json 並填好內容。"
        )
    config = json.loads(config_path.read_text(encoding="utf-8"))
    check_config_filled(config, config_path)
    return config


def find_unfilled_fields(config: dict) -> list[str]:
    """回傳還沒填好的必填欄位名稱。介面用這個決定按鈕要不要禁用，
    後端用這個擋下實際執行，兩邊共用同一套判斷才不會不一致。"""
    required = ["enrollment_token", "wifi_ssid", "wifi_password"]
    unfilled = []
    for key in required:
        value = str(config.get(key, "")).strip()
        if (
            not value
            or "【待填】" in value
            or value.startswith("貼 ")
            or value.startswith("TEST-")
        ):
            unfilled.append(key)
    return unfilled


def check_config_filled(config: dict, config_path: Path) -> None:
    """擋掉「忘了填」就打包的情況。現場趕時間漏填一欄，程式照樣產出安裝包，
    推到幾十台裝置之後才發現註冊不上，那時候已經來不及了。"""
    labels = {
        "enrollment_token": "ChromeOS Flex 註冊權杖",
        "wifi_ssid": "Wi-Fi 名稱",
        "wifi_password": "Wi-Fi 密碼",
    }
    unfilled = find_unfilled_fields(config)
    if unfilled:
        detail = "\n".join(
            f"  - {key}（{labels[key]}）目前是：{config.get(key) or '空的'}"
            for key in unfilled
        )
        raise FrdError(
            f"設定檔還沒填完：{config_path}\n"
            + detail
            + "\n\n填好這幾欄再跑一次。"
            "（測試用的 TEST- 開頭值也會被擋，避免誤用測試設定做正式部署）"
        )


def ensure_frd_package(config: dict | None = None, log=print) -> Path:
    """第一次執行自動下載並解壓官方 FRD 套件，之後重複使用同一份。"""
    if FRD_EXTRACT_DIR.exists() and any(FRD_EXTRACT_DIR.iterdir()):
        return FRD_EXTRACT_DIR

    TOOLS_DIR.mkdir(parents=True, exist_ok=True)
    url, source = resolve_download_url(config or {}, "frd")
    log(f"[下載] 從{source}取得 FRD 套件... {url}")
    try:
        download_file(url, FRD_ZIP_PATH, log=log)
    except Exception as e:
        raise FrdError(
            f"從{source}下載 FRD 套件失敗：{e}\n"
            f"可以改選另一個下載來源重試，或手動從 {url} 下載後解壓到 {FRD_EXTRACT_DIR}"
        )
    try:
        log("[解壓] 正在解壓 FRD 套件（約 1 GB，需要一點時間）...")
        with zipfile.ZipFile(FRD_ZIP_PATH) as zf:
            zf.extractall(FRD_EXTRACT_DIR)
    except Exception as e:
        raise FrdError(f"解壓 FRD 套件失敗：{e}")
    log(f"[完成] 已解壓到 {FRD_EXTRACT_DIR}")
    return FRD_EXTRACT_DIR


def resolve_frd_source_dir(config: dict, log=print) -> Path:
    """依 config 的 frd_source_dir 決定要用哪個 FRD 套件資料夾，沒填就自動下載。"""
    frd_source_dir_value = config.get("frd_source_dir")
    if frd_source_dir_value:
        frd_source_dir = Path(frd_source_dir_value)
        if not frd_source_dir.exists():
            raise FrdError(
                f"找不到 FRD 套件資料夾：{frd_source_dir}\n"
                f"把 secrets\\config.json 的 frd_source_dir 刪掉或留空，會自動下載官方套件；"
                f"或確認這個路徑真的有解壓好的 FRD 套件。"
            )
        return frd_source_dir
    return ensure_frd_package(config, log=log)


def ensure_vector(dest_dir: Path, config: dict | None = None, log=print) -> bool:
    """下載 Vector 記錄器並把 vector.exe 放進 FRD 套件資料夾，回傳有沒有成功。

    這裡刻意不拋錯只回 False：沒有記錄器仍然可以部署，只是事後查不到記錄，
    不值得為了它把整個流程擋下來。
    """
    dest_exe = dest_dir / "vector.exe"
    if dest_exe.exists():
        return True

    cached_exe = VECTOR_EXTRACT_DIR / "vector.exe"
    if not cached_exe.exists():
        TOOLS_DIR.mkdir(parents=True, exist_ok=True)
        try:
            url, source = resolve_download_url(config or {}, "vector")
            log(f"[下載] 從{source}取得 Vector 記錄器... {url}")
            download_file(url, VECTOR_ZIP_PATH, log=log)
            with zipfile.ZipFile(VECTOR_ZIP_PATH) as zf:
                zf.extractall(VECTOR_EXTRACT_DIR)
        except Exception as e:
            log(f"[警告] 取得 Vector 失敗：{e}")
            log("[警告] 沒有 Vector 就不會產生 agent.log，遠端部署將無法事後查看記錄。")
            return False

        # zip 內是 vector-x.y.z-.../bin/vector.exe 這種結構，撈出來放到固定位置
        found = list(VECTOR_EXTRACT_DIR.rglob("vector.exe"))
        if not found:
            log("[警告] Vector 壓縮檔裡找不到 vector.exe，跳過記錄器設定。")
            return False
        shutil.copy2(found[0], cached_exe)

    shutil.copy2(cached_exe, dest_exe)
    log(f"[產生] vector.exe 已放進 {dest_dir}")
    return True


def render_template(template_path: Path, values: dict) -> str:
    text = template_path.read_text(encoding="utf-8")
    for key, value in values.items():
        text = text.replace(f"{{{{{key}}}}}", str(value))
    return text


def build_config_files(config: dict, dest_dir: Path, log=print) -> None:
    """依 templates/ 產生 FRD 真正吃的 agent.toml + wifi.onc（＋選用的 Vector 記錄器）。"""
    dest_dir.mkdir(parents=True, exist_ok=True)

    # GUID 要帶大括號，格式照官方 samples/onc/wifi_wpa_psk.json
    onc_values = {
        "WIFI_GUID": "{" + str(uuid.uuid4()) + "}",
        "WIFI_SSID": config["wifi_ssid"],
        "WIFI_PASSWORD": config["wifi_password"],
    }
    onc_text = render_template(TEMPLATES_DIR / "wifi-onc.template.json", onc_values)
    (dest_dir / "wifi.onc").write_text(onc_text, encoding="utf-8")

    logging_block = ""
    if config.get("enable_logging", True) and ensure_vector(dest_dir, config, log=log):
        vector_text = (TEMPLATES_DIR / "vector.toml.template").read_text(encoding="utf-8")
        (dest_dir / "vector.toml").write_text(vector_text, encoding="utf-8")
        # 參數照官方 samples/deployment.ps1 的 $sidecar_logger_args
        logging_block = (
            "\n# 記錄器：把 agent 的輸出落地成同目錄的 agent.log\n"
            "sidecar_logger_exe = 'vector.exe'\n"
            "sidecar_logger_args = ["
            "'--no-graceful-shutdown-limit', '--require-healthy=true', "
            "'--config', './vector.toml']\n"
        )

    agent_values = {
        "ENROLLMENT_TOKEN": config["enrollment_token"],
        "ONC_FILE_NAME": "wifi.onc",
        "DRY_RUN": "true" if config.get("dry_run", True) else "false",
        "LOGGING_BLOCK": logging_block,
    }
    agent_text = render_template(TEMPLATES_DIR / "agent.toml.template", agent_values)
    (dest_dir / "agent.toml").write_text(agent_text, encoding="utf-8")

    log(f"[產生] agent.toml / wifi.onc 已寫入 {dest_dir}")
    if config.get("dry_run", True):
        log(
            "[提醒] 目前是模擬測試模式（dry_run），只做檢查不會動硬碟。"
            "確認流程沒問題後才切換到正式部署模式。"
        )
    else:
        log("[警告] 目前是正式部署模式，執行後裝置的 Windows 會被清空，不可逆。")
