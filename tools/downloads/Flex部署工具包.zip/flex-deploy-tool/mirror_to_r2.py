"""
把官方套件鏡像一份到 Cloudflare R2，讓介面上的「公司鏡像」那個下載來源可以用。

為什麼要有這個選項：
1. 版本鎖定 —— Google 的 frd-latest.zip 是滾動更新的，哪天推了壞版本，
   手上要有「已知能動」的那份可以退回
2. 公司內部來源 —— 員工在別台電腦第一次用時可以從自己的鏡像拉

⚠ 這支是「Steve 專用的管理工具」，不是員工要跑的東西，所以用了 boto3。
   員工端的下載路徑（frd_common.py）維持只用標準函式庫，不必裝任何套件。

⚠ 費用：R2 免費額度是 10 GB 儲存、對外流量免費，我們只放約 1 GB，實際是 0 元。
   但開通 R2 要「完成結帳流程加入 R2 訂閱」（官方入門文件原文），
   官方文件沒寫明要不要綁信用卡，第一次開通時自己確認一下。

⚠ 憑證跟 cf 那把 API Token 不是同一種：
   R2 的檔案上傳走 S3 相容介面，要的是「R2 API Token」產生的
   Access Key ID + Secret Access Key，到
   dash.cloudflare.com → R2 → Manage R2 API Tokens 建立。
   建好後寫進 steve0802\r2-credentials.txt，格式：
       account_id=xxxxxxxx
       access_key_id=xxxxxxxx
       secret_access_key=xxxxxxxx
       bucket=flex-deploy-mirror
       public_base_url=https://pub-xxxxxxxx.r2.dev

用法：
    python mirror_to_r2.py              上傳 FRD 套件與 Vector
    python mirror_to_r2.py --check      只檢查憑證與 bucket，不上傳
"""

import argparse
import datetime
import sys
import threading
from pathlib import Path

from frd_common import FRD_ZIP_PATH, VECTOR_ZIP_PATH

CRED_PATH = Path(r"D:\ClaudeOnly\steve0802\r2-credentials.txt")


def load_credentials() -> dict:
    if not CRED_PATH.exists():
        sys.exit(
            f"找不到 R2 憑證：{CRED_PATH}\n\n"
            "建立步驟：\n"
            "1. dash.cloudflare.com → 選 hunglun2026 帳號 → R2（第一次要先完成開通流程）\n"
            "2. Manage R2 API Tokens → Create API Token，權限選 Object Read & Write\n"
            "3. 記下 Access Key ID 與 Secret Access Key（只會顯示一次）\n"
            "4. 建一個 bucket（例如 flex-deploy-mirror），Settings 開啟 Public Access\n"
            f"5. 把資訊寫進 {CRED_PATH}，格式見這支程式開頭的說明\n"
        )
    creds = {}
    for line in CRED_PATH.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        creds[key.strip()] = value.strip()

    required = ["account_id", "access_key_id", "secret_access_key", "bucket"]
    missing = [k for k in required if not creds.get(k)]
    if missing:
        sys.exit(f"{CRED_PATH} 少了這幾個欄位：{', '.join(missing)}")
    return creds


class Progress:
    """boto3 的 upload_file 會不斷回報已上傳位元組，換算成百分比印出來。"""

    def __init__(self, total: int, label: str):
        self.total = total
        self.label = label
        self.done = 0
        self.last = -1
        self.lock = threading.Lock()

    def __call__(self, bytes_amount: int):
        with self.lock:
            self.done += bytes_amount
            percent = self.done * 100 // self.total if self.total else 0
            if percent >= self.last + 5:
                self.last = percent
                print(f"  {self.label}：{percent}%（{self.done // 1048576} / {self.total // 1048576} MB）")


def main():
    parser = argparse.ArgumentParser(description="把官方套件鏡像到 Cloudflare R2")
    parser.add_argument("--check", action="store_true", help="只檢查憑證與 bucket，不上傳")
    args = parser.parse_args()

    try:
        import boto3
        from boto3.s3.transfer import TransferConfig
    except ImportError:
        sys.exit("需要 boto3：pip install boto3")

    creds = load_credentials()
    bucket = creds["bucket"]

    client = boto3.client(
        "s3",
        endpoint_url=f"https://{creds['account_id']}.r2.cloudflarestorage.com",
        aws_access_key_id=creds["access_key_id"],
        aws_secret_access_key=creds["secret_access_key"],
        region_name="auto",
    )

    try:
        client.head_bucket(Bucket=bucket)
        print(f"[確認] bucket「{bucket}」連得上")
    except Exception as e:
        sys.exit(f"連不上 bucket「{bucket}」：{e}\n先確認 bucket 名稱正確、憑證權限是 Object Read & Write。")

    if args.check:
        print("[完成] 憑證與 bucket 都正常，可以上傳。")
        return

    # FRD 套件約 966 MB，超過 wrangler r2 object put 的 315 MB 單次上傳上限，
    # 所以走 boto3 的分段上傳（它會自己切、自己重試，不必手寫）
    transfer = TransferConfig(
        multipart_threshold=300 * 1024 * 1024, multipart_chunksize=100 * 1024 * 1024
    )
    today = datetime.datetime.now().strftime("%Y-%m-%d")

    jobs = [
        (FRD_ZIP_PATH, f"frd-{today}.zip", "frd-current.zip", "FRD 套件"),
        (VECTOR_ZIP_PATH, f"vector-{today}.zip", "vector-current.zip", "Vector 記錄器"),
    ]

    for path, dated_key, current_key, label in jobs:
        if not path.exists():
            print(f"[略過] {label} 還沒下載到本機（{path.name}），先用介面按一次「準備套件」")
            continue
        size = path.stat().st_size
        print(f"[上傳] {label}（{size // 1048576} MB）→ {dated_key}")
        client.upload_file(
            str(path), bucket, dated_key,
            Callback=Progress(size, label), Config=transfer,
        )
        # 再複製一份成 current：員工端固定抓 current，
        # 帶日期那份純粹保留歷史版本，要退版時把 current 覆蓋回去就好
        print(f"[複製] {dated_key} → {current_key}")
        client.copy_object(
            Bucket=bucket,
            Key=current_key,
            CopySource={"Bucket": bucket, "Key": dated_key},
        )
        print(f"[完成] {label} 已鏡像")

    base = creds.get("public_base_url", "").rstrip("/")
    print("\n完成。把下面這行填進 secrets\\config.json，介面上的「公司鏡像」才會生效：")
    print(f'  "r2_mirror_base_url": "{base or "<你的 R2 公開網址>"}"')


if __name__ == "__main__":
    main()
