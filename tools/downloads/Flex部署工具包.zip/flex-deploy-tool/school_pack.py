"""一鍵替某間學校產生 Intune 安裝包（模擬版＋正式版）。

學校清單放 secrets\\intune-schools.json（含權杖與 Wi-Fi 密碼，已加 .gitignore）。
實際打包全部交給 intune_flex_packager.run_packaging，這支只負責：選學校、驗格式、
連跑兩次（模擬、正式）、把成品收進 output\\<學校>\\ 並附上傳清單。

用法：
    python -X utf8 school_pack.py                  文字選單
    python -X utf8 school_pack.py --list           列出學校（權杖只顯示前 8 碼）
    python -X utf8 school_pack.py --school 某國小 --yes   直接替該校產兩個包
"""
import argparse
import datetime
import json
import re
import shutil
import sys
from pathlib import Path

from frd_common import PROJECT_DIR, FrdError
from intune_flex_packager import OUTPUT_DIR, run_packaging

SCHOOLS_FILE = PROJECT_DIR / "secrets" / "intune-schools.json"
TOKEN_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")
# Microsoft 官方：直接寫 powershell.exe 會用 32 位元執行，要走 Sysnative
INSTALL_CMD = (r"%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe "
               r"-NoProfile -ExecutionPolicy Bypass -File .\intune-install.ps1")
BAD_NAME_CHARS = re.compile(r'[\\/:*?"<>|]')


def load_schools() -> list[dict]:
    if not SCHOOLS_FILE.exists():
        return []
    try:
        return json.loads(SCHOOLS_FILE.read_text(encoding="utf-8"))
    except ValueError:
        raise FrdError(f"學校清單檔壞掉了：{SCHOOLS_FILE}\n"
                       "把它改名或刪掉後重新新增學校（同資料夾若有 .bak 是上一次的備份）。")


def save_schools(schools: list[dict]) -> None:
    """先完整轉成文字、寫進暫存檔、再換掉正式檔，中途出錯不會把原本的清單截成空檔。"""
    text = json.dumps(schools, ensure_ascii=False, indent=2)
    text.encode("utf-8")  # 先確認編得出來（輸入的字元有問題時在這裡就停，不動原檔）
    SCHOOLS_FILE.parent.mkdir(parents=True, exist_ok=True)
    if SCHOOLS_FILE.exists():
        shutil.copy2(SCHOOLS_FILE, SCHOOLS_FILE.with_suffix(".json.bak"))
    tmp = SCHOOLS_FILE.with_suffix(".json.tmp")
    tmp.write_text(text, encoding="utf-8")
    tmp.replace(SCHOOLS_FILE)


def mask(token: str) -> str:
    return token[:8] + "…"


def find_school(schools: list[dict], name: str) -> dict:
    hit = [s for s in schools if s["name"] == name]
    if not hit:
        raise FrdError(f"清單裡沒有「{name}」。現有：{'、'.join(s['name'] for s in schools) or '（空的）'}")
    return hit[0]


def validate(school: dict) -> None:
    if BAD_NAME_CHARS.search(school["name"]) or not school["name"].strip():
        raise FrdError("學校名稱不能空白，也不能含 \\ / : * ? \" < > | 這些符號（要拿來當資料夾名稱）。")
    if not TOKEN_RE.match(school["token"]):
        raise FrdError("權杖格式不對：應該是 36 個字元、小寫英數字加四個減號，"
                       "例如 xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx。請從後台重新複製。")
    if not school["wifi_ssid"].strip() or not school["wifi_password"].strip():
        raise FrdError("Wi-Fi 名稱與密碼都要填。打錯的話電腦會轉成功，但全部註冊不上。")


def build_school(school: dict, log=print) -> Path:
    """替一間學校連跑模擬版、正式版，回傳該校成品資料夾。"""
    validate(school)
    stamp = f"{datetime.datetime.now():%Y%m%d-%H%M}"
    dest = OUTPUT_DIR / school["name"]
    dest.mkdir(parents=True, exist_ok=True)
    made = {}
    for dry_run, label in ((True, "DRYRUN"), (False, "REAL")):
        log(f"\n===== {school['name']}：產生{'模擬版（不動硬碟）' if dry_run else '正式版（會清空 Windows）'} =====")
        config = {
            "enrollment_token": school["token"],
            "no_enrollment": False,
            "wifi_ssid": school["wifi_ssid"],
            "wifi_password": school["wifi_password"],
            "dry_run": dry_run,
            "enable_logging": True,
            "frd_source_dir": "",
            "download_source": "official",
        }
        produced = run_packaging(config, log=log)
        target = dest / f"{label}-{stamp}.intunewin"
        target.unlink(missing_ok=True)
        shutil.move(str(produced), str(target))
        made[label] = target
    write_upload_sheet(school, made, dest, stamp)
    return dest


def write_upload_sheet(school: dict, made: dict, dest: Path, stamp: str) -> None:
    sheet = dest / f"上傳清單-{stamp}.txt"
    sheet.write_text(
        f"學校：{school['name']}　權杖：{mask(school['token'])}　產生時間：{stamp}\n"
        "（這份清單不含完整權杖與 Wi-Fi 密碼，可以放心貼給同事）\n\n"
        f"【模擬版】{made['DRYRUN'].name}　Intune App 名稱建議：Flex模擬-{school['name']}\n"
        f"【正式版】{made['REAL'].name}　Intune App 名稱建議：Flex正式-{school['name']}（會清空 Windows）\n\n"
        "兩個 App 的欄位只有「偵測規則的檔名」不同，其他一樣：\n"
        f"  安裝命令　　　　{INSTALL_CMD}\n"
        "  解除安裝命令　　cmd.exe /c exit 0\n"
        "  安裝行為　　　　系統\n"
        "  安裝時間　　　　120（這是等待上限，不是要跑 120 分鐘）\n"
        "  重新啟動行為　　依據傳回碼決定行為\n"
        "  需求　　　　　　作業系統架構＝64 位元；所需磁碟空間＝10240 MB；最低作業系統＝Windows 10 1607 以上\n"
        "  傳回碼　　　　　保留預設（0、1707 成功；3010 軟性重開；1641 強制重開；1618 重試）\n"
        "  偵測規則　　　　規則類型＝檔案；路徑＝%ProgramData%\\frd-deploy；\n"
        "                  　模擬版 檔案＝dryrun-ok.txt；正式版 檔案＝install-started.txt；\n"
        "                  　偵測方法＝檔案或資料夾存在\n"
        "  指派　　　　　　裝置群組、類型 Required（不要指派給使用者）\n",
        encoding="utf-8",
    )


def prompt(text: str) -> str:
    return input(text).strip()


def add_school(schools: list[dict]) -> None:
    school = {
        "name": prompt("學校名稱（會當資料夾名稱）："),
        "token": prompt("權杖（後台複製的 36 字元）：").lower(),
        "wifi_ssid": prompt("Wi-Fi 名稱："),
        "wifi_password": prompt("Wi-Fi 密碼："),
    }
    validate(school)
    if any(s["name"] == school["name"] for s in schools):
        raise FrdError(f"「{school['name']}」已經在清單裡，要改請先刪除再新增。")
    schools.append(school)
    save_schools(schools)
    print(f"已新增「{school['name']}」。")


def menu() -> None:
    while True:
        schools = load_schools()
        print("\n====== Flex Intune 安裝包（依學校）======")
        for i, s in enumerate(schools, 1):
            print(f"  {i}. {s['name']}　（權杖 {mask(s['token'])}）")
        print("  A. 新增學校　D. 刪除學校　Q. 離開")
        pick = prompt("輸入學校編號產生安裝包，或選功能：").upper()
        try:
            if pick == "Q":
                return
            if pick == "A":
                add_school(schools)
            elif pick == "D":
                n = prompt("要刪除的編號：")
                gone = schools.pop(int(n) - 1)
                save_schools(schools)
                print(f"已刪除「{gone['name']}」。")
            elif pick.isdigit() and 1 <= int(pick) <= len(schools):
                s = schools[int(pick) - 1]
                print(f"\n即將替「{s['name']}」產生模擬版與正式版，各約 1 GB，需要幾分鐘。")
                if prompt("輸入 Y 開始：").upper() == "Y":
                    dest = build_school(s)
                    print(f"\n完成。成品在：{dest}\n照裡面的「上傳清單」到 Intune 建 App。")
            else:
                print("沒有這個選項。")
        except (FrdError, ValueError, IndexError) as e:
            print(f"[錯誤] {e}")


def main() -> None:
    # 輸入是貼上或管線時，Windows 預設用系統碼頁（cp950）解讀，中文會變成壞字元；統一用 UTF-8。
    # 一般在視窗裡打字（互動式）維持原本行為。
    if not sys.stdin.isatty():
        sys.stdin.reconfigure(encoding="utf-8", errors="replace")
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    p = argparse.ArgumentParser(description="替某間學校產生 Intune 安裝包")
    p.add_argument("--list", action="store_true", help="列出學校")
    p.add_argument("--school", help="學校名稱")
    p.add_argument("--yes", action="store_true", help="不再確認，直接產生")
    args = p.parse_args()
    try:
        if args.list:
            for s in load_schools():
                print(f"{s['name']}\t{mask(s['token'])}")
        elif args.school:
            school = find_school(load_schools(), args.school)
            if not args.yes:
                sys.exit("要產生請加 --yes（會連跑模擬版與正式版，各約 1 GB）。")
            print(f"\n完成。成品在：{build_school(school)}")
        else:
            menu()
    except FrdError as e:
        sys.exit(f"[錯誤] {e}")


if __name__ == "__main__":
    main()
