@echo off
rem ChromeOS Flex one-click conversion. Double-click, then click "Yes" on the admin prompt.
rem The cmd part stays ASCII-only; the PowerShell part below #__PS__ is read as UTF-8.
setlocal
net session >nul 2>&1
if errorlevel 1 (
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
set "FRD_BAT_DIR=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s = Get-Content -LiteralPath '%~f0' -Raw -Encoding UTF8; $i = $s.IndexOf([char]10 + '#__PS__'); Invoke-Expression $s.Substring($i + 1)"
echo.
pause
exit /b

#__PS__
# ===== 這台電腦轉 ChromeOS Flex：照 Google 官方 samples/deployment.ps1 的流程，另加檢查與先模擬再正式 =====

# ----- 設定（通常只要改這四行）-----
# 客戶的 Google 帳號有買 CEU 才填；留空＝不註冊。官方：權杖空白會安裝 Flex，但裝置不會自動註冊
$ENROLLMENT_TOKEN = ''
# 只有填了權杖才會生效。官方：onc_file「需要先定義註冊權杖」。不註冊時開機後在歡迎畫面自己選 Wi-Fi
# 有權杖但要插網路線的話，這兩行留空，會自動改寫成官方的有線網路設定
$WIFI_SSID = ''
$WIFI_PASSWORD = ''
# $true＝只跑模擬測試（只檢查、不動硬碟），結果打包到桌面傳回來給技術人員看。每種新機型的第一台都先這樣跑
# 確認沒問題再改成 $false，才會真的轉換。預設 $true：忘了改最多就是多測一次，不會誤清電腦
$ONLY_TEST = $true

$BUNDLE_URL = 'https://dl.google.com/cros-frd/frd-latest.zip'
$VECTOR_URL = 'https://packages.timber.io/vector/0.47.0/vector-0.47.0-x86_64-pc-windows-msvc.zip'
$DEPLOY_DIR = 'C:\deploy'

# 測試用開關（正式使用不要設）：換資料夾、自動回答 Y、在執行 agent.exe 之前停下
if ($env:FRD_TEST_DIR) { $DEPLOY_DIR = $env:FRD_TEST_DIR }
if ($env:FRD_TEST_TOKEN) { $ENROLLMENT_TOKEN = $env:FRD_TEST_TOKEN; $WIFI_SSID = $env:FRD_TEST_SSID; $WIFI_PASSWORD = $env:FRD_TEST_PASS }
$AUTO_YES = [bool]$env:FRD_AUTO_YES
$STOP_BEFORE_AGENT = [bool]$env:FRD_STOP_BEFORE_AGENT
$SKIP_DOWNLOAD = [bool]$env:FRD_TEST_SKIP_DOWNLOAD   # 測試用：資料夾裡已經有 agent.exe，不重新下載
if ($env:FRD_TEST_ONLY) { $ONLY_TEST = $env:FRD_TEST_ONLY -eq '1' }
# 結果包放桌面；測試時放在測試資料夾
$REPORT_DIR = if ($env:FRD_TEST_DIR) { $DEPLOY_DIR } else { [Environment]::GetFolderPath('Desktop') }

$ErrorActionPreference = 'Stop'

function Say([string]$msg, [string]$color = 'White') { Write-Host $msg -ForegroundColor $color }
# 把記錄打包成一個 zip 放桌面，對方只要傳這個檔案。不放 agent.toml、onc.json（裡面有權杖和 Wi-Fi 密碼）
function Save-Report {
    try { Stop-Transcript | Out-Null } catch {}
    $files = @(Get-ChildItem -LiteralPath $DEPLOY_DIR -File | Where-Object { $_.Name -like '*.log' -or $_.Name -eq 'convert-log.txt' })
    if (-not $files) { return }
    $zipOut = Join-Path $REPORT_DIR ('Flex結果-{0}-{1}.zip' -f $env:COMPUTERNAME, (Get-Date -Format 'MMdd-HHmm'))
    try {
        Compress-Archive -LiteralPath $files.FullName -DestinationPath $zipOut -Force
        Say ''
        Say "結果已經打包好：$zipOut" 'Cyan'
        Say '請把這個檔案傳給技術人員。'
    } catch {
        Say "打包失敗，請直接把 $DEPLOY_DIR 裡的 .log 和 convert-log.txt 傳給技術人員。" 'Yellow'
    }
}
function Fail([string]$msg, [switch]$NoReport) {
    Say ''
    Say "[停止] $msg" 'Red'
    Say 'Windows 沒有被改動，可以照常使用。' 'Yellow'
    if (-not $NoReport) { Save-Report }
    exit 1
}

New-Item -ItemType Directory -Force -Path $DEPLOY_DIR | Out-Null
Start-Transcript -Path (Join-Path $DEPLOY_DIR 'convert-log.txt') -Append | Out-Null

Say ''
Say '==============================================' 'Cyan'
Say '   把這台電腦轉換成 ChromeOS Flex' 'Cyan'
Say '==============================================' 'Cyan'
Say ''
if ($ONLY_TEST) {
    Say '這次只做模擬測試：只檢查這台電腦能不能轉，不會改動任何東西，Windows 照常可以用。' 'Green'
    Say '跑完會在桌面產生一個結果檔，請傳給技術人員。'
} else {
    Say '轉換完成後，這台電腦的 Windows 和裡面所有資料都會被清空，無法復原。' 'Red'
}
if ($ENROLLMENT_TOKEN) {
    Say '轉完會自動註冊到貴單位的 Google 管理控制台。'
} else {
    Say '這次不註冊：轉完是一般的 ChromeOS Flex，開機後在歡迎畫面自己選 Wi-Fi、登入 Google 帳號。'
}
Say ''
if ($AUTO_YES) {
    $ans = 'Y'
} elseif ($ONLY_TEST) {
    $ans = Read-Host '要開始測試，請輸入 Y 再按 Enter'
} else {
    $ans = Read-Host '資料都備份好、確定要繼續，請輸入 Y 再按 Enter'
}
if ($ans -ne 'Y' -and $ans -ne 'y') { Fail '已取消。' -NoReport }

# ----- 1. 檢查硬體（Google 官方門檻：UEFI、GPT、32GB 以上、可用 5GB、Windows 10/11）-----
Say ''
Say '[1/5] 檢查這台電腦...' 'Cyan'
$os = (Get-CimInstance Win32_OperatingSystem).Caption
$cs = Get-CimInstance Win32_ComputerSystem
# 2026-10-07 實機（學校 ASUS SD310）：WMI 的硬碟類別不見，Get-Partition 丟「類別無效」0x80041010。
# FRD 自己也靠 WMI，這種電腦不修好轉不了，所以先用白話停下來，修法寫在手冊。
try { $disk = Get-Partition -DriveLetter C -ErrorAction Stop | Get-Disk -ErrorAction Stop }
catch {
    Say "  讀不到硬碟資訊：$($_.Exception.Message)" 'Yellow'
    Fail 'Windows 的系統資訊資料庫（WMI）異常，讀不到硬碟資訊。學校電腦常見原因是還原卡或還原軟體；修法見說明書「WMI 異常」。'
}
$freeGB = [math]::Round((Get-PSDrive C).Free / 1GB, 1)
Say ("  型號：{0} {1}" -f $cs.Manufacturer, $cs.Model)
Say ("  系統：{0}｜開機模式：{1}｜磁碟：{2}，{3}GB，可用 {4}GB" -f $os, $env:firmware_type, $disk.PartitionStyle, [math]::Round($disk.Size / 1GB), $freeGB)
if ($os -notmatch 'Windows 1[01]') { Fail '只支援 Windows 10 或 11。' }
if ($env:firmware_type -ne 'UEFI') { Fail '開機模式不是 UEFI，FRD 不支援。' }
if ("$($disk.PartitionStyle)" -ne 'GPT') { Fail '系統磁碟不是 GPT 格式，FRD 不支援。' }
if ($disk.Size / 1GB -lt 32) { Fail '系統磁碟小於 32GB。' }
# 官方寫 5GB，但同頁也寫「已知問題：部分裝置需要 9GB」；另外下載與解壓縮套件約要 3GB
if ($freeGB -lt 12) { Fail "C 槽可用空間只有 $freeGB GB，至少要 12GB（官方已知部分裝置需要 9GB＋下載套件 3GB）。" }
$power = Get-CimInstance -Namespace root/wmi -ClassName BatteryStatus -ErrorAction SilentlyContinue | Select-Object -First 1
if ($power -and -not $power.PowerOnline) { Fail '請先插上電源再執行，轉換途中斷電會讓電腦開不了機。' }
Say '  硬體條件合格。型號是否在 Google 認證清單上，請另外確認。' 'Green'

# ----- 2. 下載 FRD 套件（官方網址，不需申請）-----
Say ''
# 這個檔案旁邊（例如隨身碟）放了 frd-latest.zip／vector.zip 就直接用，不必每台都向網路下載
$localFrd = if ($env:FRD_BAT_DIR) { Join-Path $env:FRD_BAT_DIR 'frd-latest.zip' } else { '' }
$localVector = if ($env:FRD_BAT_DIR) { Join-Path $env:FRD_BAT_DIR 'vector.zip' } else { '' }
$zip = Join-Path $DEPLOY_DIR 'frd.zip'
if ($SKIP_DOWNLOAD) { Say '[2/5] [測試模式] 跳過下載' 'Yellow' } elseif ($localFrd -and (Test-Path -LiteralPath $localFrd)) {
    Say '[2/5] 使用同資料夾的 frd-latest.zip（不用上網下載）...' 'Cyan'
    Copy-Item -LiteralPath $localFrd -Destination $zip -Force
} else {
    Say '[2/5] 從 Google 下載 ChromeOS Flex（約 1GB，依網速需要幾分鐘）...' 'Cyan'
    try {
        Start-BitsTransfer -Source $BUNDLE_URL -Destination $zip -DisplayName 'ChromeOS Flex'
    } catch {
        Say '  背景下載服務不能用，改用一般下載（畫面不會顯示進度，請耐心等）...' 'Yellow'
        (New-Object System.Net.WebClient).DownloadFile($BUNDLE_URL, $zip)
    }
    Say '  下載完成。'
}
if (-not $SKIP_DOWNLOAD) {
    Say '  解壓縮中（約 1GB，請稍等）...'
    # PowerShell 5.1 的 Expand-Archive 畫進度條很耗時，關掉快很多
    $oldProgress = $ProgressPreference; $ProgressPreference = 'SilentlyContinue'
    Expand-Archive -Path $zip -DestinationPath $DEPLOY_DIR -Force
    $ProgressPreference = $oldProgress
    Remove-Item $zip
}
if (-not (Test-Path (Join-Path $DEPLOY_DIR 'agent.exe'))) { Fail '套件解壓後找不到 agent.exe，下載可能不完整，請重新執行。' }

# 記錄器（官方同款 Vector）：把執行過程存成 agent.log，失敗時才查得到原因。抓不到不影響轉換
$useVector = $false
if (-not $SKIP_DOWNLOAD) {
try {
    $vzip = Join-Path $DEPLOY_DIR 'vector.zip'
    if ($localVector -and (Test-Path -LiteralPath $localVector)) { Copy-Item -LiteralPath $localVector -Destination $vzip -Force }
    else { (New-Object System.Net.WebClient).DownloadFile($VECTOR_URL, $vzip) }
    Expand-Archive -Path $vzip -DestinationPath (Join-Path $DEPLOY_DIR 'vector') -Force
    Copy-Item (Join-Path $DEPLOY_DIR 'vector\bin\vector.exe') (Join-Path $DEPLOY_DIR 'vector.exe') -Force
    Remove-Item $vzip
    $useVector = $true
} catch {
    Say '  記錄器下載失敗，略過（不影響轉換，只是不會留下 agent.log）。' 'Yellow'
}
}

# ----- 3. 寫設定 -----
Say ''
Say '[3/5] 寫入設定...' 'Cyan'
$utf8 = New-Object System.Text.UTF8Encoding($false)
function Write-AgentConfig([bool]$dryRun) {
    $lines = @("data_dir = 'install'")
    if ($ENROLLMENT_TOKEN) {
        $lines += "enrollment_token = '$ENROLLMENT_TOKEN'"
        if ($WIFI_SSID) {
            # 用 ConvertTo-Json 產生，Wi-Fi 名稱或密碼有引號、反斜線也不會壞
            $onc = [ordered]@{
                Type = 'UnencryptedConfiguration'
                NetworkConfigurations = @([ordered]@{
                    GUID = '{' + [guid]::NewGuid().ToString() + '}'
                    Name = $WIFI_SSID
                    Type = 'WiFi'
                    WiFi = [ordered]@{ Passphrase = $WIFI_PASSWORD; SSID = $WIFI_SSID; Security = 'WPA-PSK'; AutoConnect = $true }
                })
            }
            [IO.File]::WriteAllText((Join-Path $DEPLOY_DIR 'onc.json'), ($onc | ConvertTo-Json -Depth 5), $utf8)
            $lines += "onc_file = 'onc.json'"
        } else {
            # 有權杖但沒填 Wi-Fi：當成插網路線，照官方 samples/onc/ethernet_basic.json 寫有線設定
            $onc = [ordered]@{
                Type = 'UnencryptedConfiguration'
                NetworkConfigurations = @([ordered]@{
                    GUID = '{' + [guid]::NewGuid().ToString() + '}'
                    Type = 'Ethernet'
                    Name = 'Ethernet'
                    Ethernet = [ordered]@{ Authentication = 'None' }
                })
            }
            [IO.File]::WriteAllText((Join-Path $DEPLOY_DIR 'onc.json'), ($onc | ConvertTo-Json -Depth 5), $utf8)
            $lines += "onc_file = 'onc.json'"
        }
    }
    if ($useVector) {
        $lines += "sidecar_logger_exe = 'vector.exe'"
        $lines += "sidecar_logger_args = ['--no-graceful-shutdown-limit', '--require-healthy=true', '--config', './vector.toml']"
    }
    $lines += "dry_run = $($dryRun.ToString().ToLower())"
    [IO.File]::WriteAllText((Join-Path $DEPLOY_DIR 'agent.toml'), ($lines -join "`r`n") + "`r`n", $utf8)
}
# Vector 設定照官方 deployment.ps1
$vectorConfig = @'
schema.log_namespace = true

[sources.agent]
type = "stdin"
decoding.codec = "json"

[sinks.stderr]
type = "console"
inputs = [ "agent" ]
target = "stderr"
encoding.codec = "logfmt"

[sinks.local_log_file]
type = "file"
inputs = [ "agent" ]
path = "agent.log"
encoding.codec = "logfmt"
'@
[IO.File]::WriteAllText((Join-Path $DEPLOY_DIR 'vector.toml'), $vectorConfig, $utf8)
Write-AgentConfig $true
Say '  完成。'

if ($STOP_BEFORE_AGENT) { Say '[測試模式] 停在執行 agent.exe 之前。' 'Yellow'; Stop-Transcript | Out-Null; exit 0 }

# ----- 4. 模擬測試：只檢查，不動硬碟 -----
# 官方記錄事件（answer/16390092）：檢查項目依序是 SystemChecked、TPMChecked、MemoryChecked、DiskChecked、FilesChecked；
# InstallSkipped＝「模擬測試結束，或檢查沒過、部署中止」，所以不能拿它當成功；InstallStarted＝「所有檢查都通過，開始破壞性操作」。
# 官方沒寫 agent.exe 結束代碼的意義，所以結束代碼不是 0 時保守地停下來。
$log = Join-Path $DEPLOY_DIR 'agent.log'
function Read-Log { if (Test-Path $log) { Get-Content $log -Raw -Encoding UTF8 } else { '' } }
Say ''
Say '[4/5] 模擬測試（只檢查，不會動硬碟）...' 'Cyan'
if (Test-Path $log) { Remove-Item $log }
Push-Location $DEPLOY_DIR
& .\agent.exe
$code = $LASTEXITCODE
Pop-Location
$dryLog = Read-Log
if (Test-Path $log) { Move-Item $log (Join-Path $DEPLOY_DIR 'agent-dryrun.log') -Force }
if ($dryLog) {
    $checks = 'SystemChecked', 'TPMChecked', 'MemoryChecked', 'DiskChecked', 'FilesChecked'
    $seen = $checks | Where-Object { $dryLog -match $_ }
    Say ("  官方檢查項目完成 {0}/5：{1}" -f @($seen).Count, ($seen -join '、'))
    if (@($seen).Count -lt 5) {
        Fail '模擬測試沒有跑完全部檢查。'
    }
}
if ($code -ne 0) { Fail "模擬測試回報錯誤（代碼 $code）。" }
Say '  模擬測試完成。' 'Green'

if ($ONLY_TEST) {
    Say ''
    Say '這次只做模擬測試，到這裡結束。硬碟完全沒有被動到，Windows 照常可以用。' 'Green'
    Save-Report
    Say '技術人員確認沒問題後，會給你正式轉換用的檔案。'
    exit 0
}

# ----- 5. 正式轉換 -----
# FRD 正式模式也會自己再跑一次全部檢查，沒過就中止（InstallSkipped），不會動硬碟。
Say ''
Say '[5/5] 開始正式轉換。過程中不要關機、不要拔電源。' 'Yellow'
Write-AgentConfig $false
Push-Location $DEPLOY_DIR
& .\agent.exe
$code = $LASTEXITCODE
Pop-Location
$realLog = Read-Log
Say ''
if ($realLog -match 'InstallStarted') {
    Say '轉換已經開始：電腦會重新開機，進入 ChromeOS Flex 安裝。' 'Green'
    Say '重新開機後的安裝不需要網路，也不用按任何東西，等它自己完成。'
    Say '如果 2 分鐘內都沒有自動重新開機，請手動重新開機一次。'
} elseif ($realLog -match 'InstallSkipped') {
    Fail '正式執行前的檢查沒有通過，FRD 自己中止了，硬碟沒有被動到。'
} else {
    Say "沒有讀到執行記錄（代碼 $code），無法判斷結果。請先不要關機。" 'Yellow'
    Save-Report
    exit 1
}
Stop-Transcript | Out-Null
