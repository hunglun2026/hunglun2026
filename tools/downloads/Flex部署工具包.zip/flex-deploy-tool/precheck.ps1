﻿# FRD 部署前檢查：這台電腦能不能用 FRD 轉成 ChromeOS Flex
# 單台：在目標電腦用系統管理員身分執行 powershell -ExecutionPolicy Bypass -File precheck.ps1
# 大量：python psexec_mass_deploy.py --precheck（會在前面加 $FrdJson = $true，改印一行 JSON）
# 只讀資訊，不改任何設定。

$os = Get-CimInstance Win32_OperatingSystem
$cs = Get-CimInstance Win32_ComputerSystem
$sys = Get-Disk | Where-Object IsSystem | Select-Object -First 1
$tpm = Get-CimInstance -Namespace root/cimv2/security/microsofttpm -ClassName Win32_Tpm -ErrorAction SilentlyContinue

$r = [ordered]@{
    computer  = $env:COMPUTERNAME
    model     = "$($cs.Manufacturer) $($cs.Model)".Trim()
    os        = $os.Caption
    firmware  = $env:firmware_type
    partition = "$($sys.PartitionStyle)"
    disk_gb   = [math]::Round($sys.Size / 1GB)
    free_gb   = [math]::Round((Get-PSDrive C).Free / 1GB, 1)
    tpm       = [bool]$tpm
}

# 官方門檻：UEFI、GPT、磁碟 32GB 以上、可用空間（見下方 9GB 說明）、Windows 10/11
$fail = @()
if ($r.firmware -ne 'UEFI') { $fail += "開機模式不是 UEFI（$($r.firmware)）" }
if ($r.partition -ne 'GPT') { $fail += "磁碟不是 GPT（$($r.partition)）" }
if ($r.disk_gb -lt 32) { $fail += "磁碟小於 32GB" }
# 官方寫 5GB，但同頁「已知問題：部分裝置需要 9GB 可用空間」，照保守的 9GB 判
if ($r.free_gb -lt 9) { $fail += "可用空間小於 9GB（官方已知部分裝置需要 9GB）" }
if ($r.os -notmatch 'Windows 1[01]') { $fail += "不是 Windows 10/11" }

if ($FrdJson) {
    # 原因交給 Python 端用中文重判，這裡只送原始數值。
    # 中文（如「專業版」）跳脫成 \uXXXX，整行只剩 ASCII，經過 PsExec 轉碼也不會壞
    # 寫成檔案讓操作端從 C$ 讀回：PsExec 在操作端沒有主控台時不會轉送遠端輸出（2026-10-02 實測）
    $json = $r | ConvertTo-Json -Compress
    $json = [regex]::Replace($json, '[^\x00-\x7F]', { '\u{0:x4}' -f [int][char]$args[0].Value })
    Set-Content -Path "$env:ProgramData\frd-precheck.json" -Value $json -Encoding ASCII
    return
}

[pscustomobject]@{
    電腦名稱   = $r.computer
    廠牌型號   = $r.model
    作業系統   = $r.os
    開機模式   = $r.firmware
    磁碟格式   = $r.partition
    磁碟大小GB = $r.disk_gb
    可用空間GB = $r.free_gb
    TPM        = if ($r.tpm) { '有' } else { '查不到（需系統管理員身分或無 TPM）' }
} | Format-List

if ($fail) {
    Write-Host '結果：不合格' -ForegroundColor Red
    $fail | ForEach-Object { Write-Host "  - $_" -ForegroundColor Red }
} else {
    Write-Host '結果：硬體條件合格' -ForegroundColor Green
}
Write-Host '最後一步要人工做：拿「廠牌型號」去 Google 認證清單比對，狀態要是「通過認證」'
Write-Host 'https://support.google.com/chromeosflex/answer/11513094'
