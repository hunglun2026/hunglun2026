# intune-flex-deploy

用 Intune 批次把 Windows 裝置轉成 ChromeOS Flex，並自動註冊進 Google Admin Console。

## ⚠ 適用機型：只做官方認證的型號

**接案第一件事是查
[Google 通過認證的型號清單](https://support.google.com/chromeosflex/answer/11513094)。**

Google 官方明文規定：「裝置如果未列在認證裝置清單中，就**不適用 Chrome Education 或
Chrome Enterprise 支援服務**。」對學校客戶來說這是紅線，他們付錢買了 Chrome Education
Upgrade，裝在未認證機器上等於自己放棄支援資格。

清單上每個型號有四種狀態，只有第一種可以做：

| 狀態 | 官方定義 | 我們的做法 |
|---|---|---|
| 通過認證 | 預期可與 ChromeOS Flex 搭配運作 | 可以接，唯一建議部署的狀態 |
| 預期會出現輕微問題 | 可能至少支援基本功能，團隊仍在改善相容性 | 先跟客戶說清楚風險並實測過再決定 |
| 預期會出現重大問題 | 已知有啟動問題等重大問題，不建議搭配使用 | 不要做 |
| 取消認證 | 已達支援終止日期 | 不要做 |

未列在清單上的機型，Google 說「可以接受可能發生問題的話可以嘗試安裝」，但同時警告
「即便功能完全正常，還是可能隨時出現重大問題」，且「無法保證 OS 定期更新的穩定性、
功能或效能」。技術上裝得起來，但那是個人自己玩的層級，**不是商用交付該做的事**。

程式本身沒有寫死機型限制（FRD 對硬體沒有技術性阻擋），所以**這條規矩要靠人守**。
清單更新頻繁，每次接案都重新查一次，不要靠記憶或舊資料。

## 背景（2026-09-10 已核對官方文件，取代 09-09 的推測版本）

Google 有一套「ChromeOS Flex Remote Deployment（FRD）」套件：一個 Windows 執行檔
`agent.exe`，搭配一個 `agent.toml` 設定檔（裡面用 `onc_file` 欄位指向另一個 ONC 格式的
Wi-Fi 設定 JSON）。透過 Intune（或 GPO／SCCM）把這個套件當一般軟體推到 Windows 裝置上
執行，它會自動：

1. 清除 TPM、重新分割磁碟
2. 安裝 ChromeOS Flex
3. 連上指定 Wi-Fi
4. 用 enrollment token 自動註冊進 Google Admin Console

⚠ **這是不可逆的操作**——執行後原本的 Windows 會被清空，裝置變成 ChromeOS Flex。

**FRD 套件本身可直接下載，不需要填表審核等待**：`https://dl.google.com/cros-frd/frd-latest.zip`。
填表單（`chromeos.google/engage/flex-remote-deployment`）拿到的只是官方部署指南的入口信，
跟套件下載權限無關——2026-09-10 曾誤信一份來源不明的「排錯指南」，裡面講的 24 小時 ACL
審核、Cloudflare 網頁工具產生設定檔等內容，經查證都是編造的，已排除。

參考資料（2026-09-10 逐頁核對過）：
- [總覽](https://support.google.com/chromeosflex/answer/16390406)
- [快速入門指南](https://support.google.com/chromeosflex/answer/16390566)
- [部署設定、監控和最佳做法](https://support.google.com/chromeosflex/answer/16390092)
- [參考資料（agent.toml 完整欄位）](https://support.google.com/chromeosflex/answer/16387032)

## 給員工用：網頁操作介面（最簡單的用法）

**雙擊 `開始操作.bat`**，瀏覽器會自動打開操作畫面，密碼跟 CEU 綁定系統一樣。
不用打指令、不用改 JSON 檔，整個流程都在畫面上點。

介面能做的事：
- 填部署設定（註冊權杖、Wi-Fi），三欄沒填完按鈕會鎖住不讓你執行
- 一鍵下載官方套件（有進度條）
- 產生 Intune 安裝包，完成後直接下載
- 直接遠端部署：裝置清單支援**從 Excel 整欄複製貼上**
- 即時看到每一台的執行狀況與記錄，完成後可下載 CSV 報告

**模擬測試 vs 正式部署**：畫面上有一條大橫幅，綠色是模擬測試（只檢查、不動硬碟），
紅色是正式部署（清空 Windows、不可逆）。要切到紅色必須手動輸入「確認部署」四個字，
按錯不會切過去。

**技術說明**（為什麼不像 CEU 那樣做成網址就好）：CEU 只是打 Google API，純網頁做得到。
這個工具要執行 `.exe`、存取區網磁碟分享、處理 1 GB 檔案，瀏覽器沙箱一律做不到，
所以是「本機跑一個小服務，瀏覽器只當畫面」。服務只綁 `127.0.0.1`，別台電腦連不進來，
每次啟動還會產生一組一次性通行碼，關掉視窗就結束。

指令列的用法（`python intune_flex_packager.py` 那些）完全保留，兩種方式共用同一套邏輯。

## 現場作業流程（到學校那天照這個做）

學校的註冊權杖要現場才拿得到，而**權杖是包進安裝包裡面的**（寫進 `agent.toml` 再打包），
所以最終的安裝包沒辦法事先做好，一定要現場填了權杖再跑一次。

**出發前先做**（在辦公室、網路快的地方）：
```powershell
python intune_flex_packager.py   # 會被擋下來說設定沒填完，這是正常的
```
重點不是產出安裝包，是讓它先把約 2.3 GB 的官方套件下載到 `tools\`。
⚠ 這份快取**不會跟著同步到別台電腦**（已被 `.gitignore` 與備份排除擋掉，避免灌爆 git），
所以**要帶有跑過這步的那台電腦去**，否則現場得用學校的網路重抓約 1 GB。

**到學校後**：
1. 跟校方拿 ChromeOS Flex 註冊權杖（他們的 Google Admin Console → 裝置 → Chrome →
   註冊權杖 → 註冊 → 選「非 ChromeOS 裝置（採用 ChromeOS Flex）」→「自動註冊」）
2. 雙擊 `開始操作.bat`，在畫面上填三個欄位並按「儲存設定」（保持綠色的模擬測試模式）
3. 選路線後按執行：Intune 路線產生安裝包、PsExec 路線直接對裝置清單部署
4. 先對 1~2 台測試機跑模擬測試，看記錄沒問題
5. 切換到紅色的正式部署模式（要輸入「確認部署」），同樣先測試機跑一次，
   去 Admin Console 確認有註冊上
6. 都對了才擴大到全部裝置

**防呆**：三個必填欄位只要有一個沒填（或還是 `【待填】`、`TEST-` 開頭的測試值），程式
會直接擋下來不打包，不會讓你帶著錯的權杖推到幾十台裝置上。

## ⚠ 什麼時候一定要用 Intune（2026-09-10 查證）

不是二選一的偏好題，多數情況是裝置狀況決定你只能走哪條。**這次的 Surface Go 案子必須
走 Intune**，有兩個獨立的技術原因：

**原因一：S 模式不准跑 .exe**
Surface Go 出廠預設是 Windows S 模式。微軟官方：「根據預設，Windows S 模式裝置
**不允許安裝和執行 Win32 應用程式**。」`agent.exe` 正是 Win32 程式，所以
**PsExec 那條路一樣失敗**，問題不在傳輸方式，在那台電腦不准執行這種程式。
處理方式：用 Intune 政策整批遠端退出 S 模式（單向，退了回不去，但反正整台要變 Flex 了），
或留在 S 模式改用 Intune 的「S 模式補充原則」（要 WDAC 建原則＋DGSS 簽章，很麻煩）。

**原因二：Entra ID 環境沒有網域管理員帳號**
被 Intune 管的機器通常只加入 Entra ID。微軟文件說這種機器在網路驗證上被當成
「工作群組」電腦，沒有傳統網域管理員帳號，而 PsExec 正是靠它連進去的。

**判斷順序**：機型有沒有認證 → 是不是 S 模式 → 是不是 Entra ID 管的 → 連不連得到。
完整的判斷表在手冊第 4 章。接案時最先要問客戶的一句話是「**你們有沒有 Intune 授權？**」，
Intune 要另外付費，不是每個客戶都有。

## 兩條部署路線

這個專案支援兩種「遠端大量部署」方式，共用同一套 `agent.toml`/`wifi.onc` 產生邏輯
（`frd_common.py`），依裝置的網路環境跟現有管理工具挑一種：

| | Intune（`intune_flex_packager.py`） | PsExec（`psexec_mass_deploy.py`） |
|---|---|---|
| 適合場景 | 裝置已用 Intune 管理，或分散在不同網路、沒有直連能力 | 裝置在同網段/VPN 內，手上有能連 admin share 的帳密 |
| 推送方式 | 上傳 `.intunewin` 到 Intune 後台，靠雲端排程派送 | 直接對裝置清單跑 PsExec，立即執行不用等排程 |
| 前置需求 | Intune 後台設定（安裝命令、指派對象） | `secrets\devices.txt` 裝置清單 + admin 帳密 |
| 速度 | 受 Intune 同步週期影響，可能要等 | 立即執行，多台並行 |

**不確定選哪個就想「這批裝置現在連不連得到、有沒有 admin 帳密」**：連得到就 PsExec 快；
連不到（跨網段、裝置在客戶端）就走 Intune。兩條路可以並用，不衝突。

## Intune 路線：完整部署流程

### 1. 取得 FRD 套件（本程式自動做）
`python intune_flex_packager.py` 第一次執行時，如果 `secrets\config.json` 的
`frd_source_dir` 留空，會自動從官方連結下載並解壓到 `tools\frd-package\`，不用手動申請。

解壓後的真實結構（2026-09-10 實際下載確認過）：
```
agent.exe                        主程式，6.6 MB
agent.toml                       官方範例設定檔（本程式會覆寫成填好值的版本）
install/flex_image.tar.xz        ChromeOS 映像檔，整包最大的東西
install/flexor_vmlinuz           安裝用核心
install/bootx64.efi 等           開機載入器
samples/deployment.ps1           官方示範部署腳本
samples/onc/wifi_wpa_psk.json    Wi-Fi（WPA-PSK）ONC 範例
samples/onc/wifi_open.json       無密碼 Wi-Fi 範例
samples/onc/ethernet_basic.json  有線網路範例
samples/vector/*.toml            Vector 記錄器設定範例
third_party/Notices.txt          開源授權
```

### 2. 準備 enrollment token（人工，Google Admin Console 做）
Google Admin Console → 選單 → 裝置 → Chrome → 註冊權杖 → 註冊 → 選「非 ChromeOS 裝置
（採用 ChromeOS Flex）」→ 繼續 → 選「自動註冊（USB 安裝程式）」→ 開始。
需要 Chrome 管理員權限，權杖沒有過期時限。

### 3. 填設定並打包（本程式做）
```powershell
copy secrets\config.example.json secrets\config.json
# 編輯 secrets\config.json，填入 enrollment_token、wifi_ssid、wifi_password
# dry_run 先留 true 跑模擬測試，確認流程沒問題後再改 false

python intune_flex_packager.py
```
會自動：
- 第一次執行時下載官方 `IntuneWinAppUtil.exe`、FRD 套件、Vector 記錄器
- 依 `templates\` 產生 `agent.toml` / `wifi.onc` / `vector.toml` 放進 FRD 套件資料夾
- 打包成 `.intunewin`，輸出到 `output\`（約 1 GB，Intune Win32 App 上限 8 GB）

**關於 Vector 記錄器**：`agent.exe` 本身只把記錄吐到主控台，遠端部署根本看不到。官方
`samples\deployment.ps1` 的做法是搭一個 Vector 當 sidecar logger，把記錄落地成
`agent.log`，本程式照做。要關掉就在 `secrets\config.json` 加 `"enable_logging": false`，
但這樣就沒有 `agent.log` 可以事後排查每台裝置的狀況，不建議關。

### 4. 上傳到 Intune 後台（人工）
1. Intune 後台 → 應用程式 → Windows → 新增 → Win32 應用程式
2. 上傳 `output\` 裡的 `.intunewin`
3. 安裝命令：`agent.exe`（系統管理員權限執行）；也可以改用套件裡的
   `sample\deployment.ps1`，內容待解壓後核對
4. **偵測規則**：官方建議改看 Google Admin Console／Directory API 確認裝置是否成功
   註冊，而不是本機偵測（裝置轉完 ChromeOS 後就不再是 Windows 軟體安裝狀態）。Intune
   介面仍會強制要填一條規則，可以先填「`agent.log` 檔案存在」這種純粹滿足介面要求的
   規則，真正的成功判斷還是回 Admin Console 看
5. **指派對象先選測試群組（1~2 台）**，且先確認 `dry_run` 是 true 跑過一輪模擬測試，
   看 `agent.log` 裡的 `InstallSkipped` 記錄沒問題後，才把 `dry_run` 改 false 並擴大到
   全部裝置——這步不可逆，別跳過測試

### 5. 驗證
- 官方文件：完整測試成功時，Windows 會在 2 分鐘內顯示安裝通知並重啟
- 測試裝置重開機後應該進入 ChromeOS Flex 的 Flexor 安裝流程
- 去 Google Admin Console → 裝置 → ChromeOS 確認裝置有出現並套用政策
- 大量部署時官方建議：先部署到一台測試，再逐步擴大到同網路/位置的裝置群組；記錄可以
  用 Vector（官方文件提到的開源工具）或自己的方案彙整成監控儀表板
- 沒問題後，回 Intune 後台把指派對象擴大到全部裝置

## PsExec 路線：直接遠端大量部署（不靠任何 MDM）

```powershell
copy secrets\config.example.json secrets\config.json
# 編輯 secrets\config.json：enrollment_token、wifi_ssid、wifi_password
# dry_run 先留 true；remote_admin_user/remote_admin_password 留空就用目前登入帳號的權限
# （前提是這個帳號在所有目標裝置上都有系統管理員權限）

copy templates\devices.example.txt secrets\devices.txt
# 編輯 secrets\devices.txt，一行填一台電腦名稱或 IP

python psexec_mass_deploy.py
```

會自動：
- 第一次執行下載官方 PsExec（Sysinternals 官方工具）與 FRD 套件
- 對清單裡每一台裝置：連 `C$` → `robocopy` 整包 FRD 套件（含 `agent.toml`/`wifi.onc`）過去
  → PsExec 遠端執行 `agent.exe` → 斷線收尾
- 預設同時處理 5 台（`--parallel` 調整），跑完印出每台成功/失敗，並輸出
  `output\psexec-deploy-result-<時間>.csv` 完整報告

⚠ **安全機制**：`dry_run` 是 `false`（真的會轉機，不可逆）時，程式會擋下來要求加 `--yes`
才會真的動手，避免忘記先跑模擬測試就對整批裝置下手。

## 已驗證 / 已知限制

2026-09-10 實際下載官方套件、跑過完整打包流程驗證的結果：

- [x] `agent.exe` 是正確的主執行檔檔名
- [x] `wifi.onc` 格式跟官方 `samples\onc\wifi_wpa_psk.json` 逐欄比對一致（GUID 要帶大括號）
- [x] `agent.toml` 的 `data_dir = 'install'` 是必填欄位，少了它 `agent.exe` 找不到映像檔
- [x] Intune 路線端到端跑通，能產出 `.intunewin`
- [x] PsExec 路線流程跑通（連不到的主機會清楚報錯、不中斷其他台、CSV 報告正常）
- [x] `dry_run: false` 沒加 `--yes` 會被擋下來，防手滑機制有效

還沒解決的：

- [ ] **兩條路線都還沒對真實裝置跑過**，上面驗的是打包與流程，不是實際轉機結果
- [ ] Intune 偵測規則怎麼填才「不會誤判失敗又不用做假規則」，目前方向是接受本機偵測
      規則只是流於形式，真正驗證靠 Admin Console
- [ ] PsExec 需要目標裝置開放 SMB（445 埠）跟 admin share，企業/裝置防火牆擋掉的話會
      連不上，要先在測試裝置確認
- [ ] Vector 的下載網址寫死 0.47.0（照官方腳本），之後版本過舊要自己更新
      `frd_common.py` 的 `VECTOR_URL`

## 踩過的坑

- **Python urllib 下載 Vector 會被 CDN 擋（403）**：`packages.timber.io` 擋掉
  `Python-urllib` 這個預設 User-Agent，同一個網址用瀏覽器 UA 就正常。`frd_common.py`
  的 `download_file()` 一律帶 `Mozilla/5.0` 解決。
- **IntuneWinAppUtil 會在專案根目錄留一個 0 byte 的 `Win32` 檔**，純垃圾，已加進
  `.gitignore`。
- **`tools\` 底下的下載物約 2.3 GB**，已加進 `tools\steve-sync\backup-exclude.txt`
  避免灌爆 ClaudeOnly 的 git（那邊已經 1.9 GB）。這些都是公開連結，跑一次程式就重抓。

## 機密檔案

`secrets\config.json` 含 enrollment token 與 Wi-Fi 密碼，已加進 `.gitignore` 不會進公開 repo，
但會照 Steve 的全域規則備份進 ClaudeOnly private repo（`safezone0619`）。
