# intune-flex-deploy

把 Windows 電腦遠端轉成 ChromeOS Flex，並自動註冊進客戶的 Google 管理控制台。
兩份圖文手冊是細節的正本：`Intune大量部署手冊.html`（Surface Go＋Intune）、`完整使用說明.html`（一鍵轉換檔與其他情況）。
開發過程與查證記錄在 `進度.md`、`學習筆記.md`。

## 先懂一件事

Google 給的轉換工具叫 **FRD**（ChromeOS Flex Remote Deployment），核心是一支 `agent.exe`：
在 Windows 裡以系統管理員身分執行，它會檢查硬體、清 TPM、在硬碟切出安裝分割區、設定開機，約 2 分鐘內自己重開機，
接著安裝 ChromeOS Flex，連上 `wifi.onc` 指定的 Wi-Fi，用註冊權杖註冊。**原本的 Windows 和資料全部清空，不可逆。**

不管哪條路線，做的事都一樣：**把 FRD 套件送到那台 Windows、以系統管理員身分跑起來。** 差別只在「怎麼送、怎麼執行」：

| 你的情況 | 用什麼 | 怎麼送過去 |
|---|---|---|
| Surface Go，客戶有 Intune | `intune_flex_packager.py`（介面「產生 Intune 安裝包」） | Intune 當成 Win32 App 推送 |
| 一般 Windows，1～幾台 | `一鍵轉換Flex.bat` | 傳檔案給對方，雙擊 |
| 一般 Windows，同網段一批、有管理員帳密 | `psexec_mass_deploy.py`（介面「直接遠端部署」） | 區網複製＋PsExec 遠端執行 |

三條路都**先模擬再正式**：模擬（`dry_run = true`）只檢查不動硬碟，通過了才可能正式轉換。
Intune 與 PsExec 兩條路跑的是同一支 `intune-install.ps1`，結束代碼看同一張表（在腳本開頭）。

## 學習路線 A：有 Intune 的 Surface Go

照順序做，每一步的畫面與細節在 `Intune大量部署手冊.html`。

1. **查型號**：Surface Go 2、Go 3 在 Google 認證清單上；Go 1、Go 4 不在，不轉。清單會更新，每次接案重查（見下方「機型規矩」）
2. **退出 S 模式**：Surface Go 出廠多是 S 模式，Intune 推 Win32 App 靠的 Intune 管理擴充功能不支援 S 模式。
   用 Intune 設定檔「版本升級和模式切換」整批退出（單向，退了回不去）
3. **Google 管理控制台**：先建好組織單位、設好政策（含學校 Wi-Fi），再產生 ChromeOS Flex 註冊權杖
4. **產生兩個安裝包**：`開始操作.bat` → 填權杖與 Wi-Fi → 綠色（模擬）產生一次、紅色（正式）產生一次。
   檔名自動標明：`flex-DRYRUN-….intunewin`、`flex-REAL-wipes-windows-….intunewin`
5. **先測 wifi.onc**：Google 官方說 FRD 不檢查 ONC，寫錯就整批註冊失敗。能借到一台 Chromebook 就在 `chrome://network` 匯入測
6. **Intune 建兩個 Win32 App**（設定照打包完印出的步驟，重點如下）
   - 安裝命令：`%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\intune-install.ps1`
     （直接寫 `powershell.exe` 會用 32 位元跑）
   - 安裝行為：系統；安裝時間：120 分；重新開機：依傳回碼
   - 偵測規則：檔案，`%ProgramData%\frd-deploy`，模擬版填 `dryrun-ok.txt`、正式版填 `install-started.txt`
7. **試點**：模擬版指派給試點群組（要含一台 4GB 記憶體的），Intune 顯示代碼 0 才往下；
   正式版先指派 1 台，到 Google 管理控制台確認註冊成功（Intune 停在「安裝中」是正常的，電腦已經在重開機）
8. **分批擴大**：手冊用八批階梯，每批對帳（Intune 清單對 Google 管理控制台的序號）

Surface 特有的事：沒有網路孔（只能 FRD＋Wi-Fi，不能網路開機）；轉完開不了機先看手冊第 18 章 Secure Boot；
BitLocker 開著時**不要**進韌體手動清 TPM（Google 官方警告，Windows 會開不了機）。

## 學習路線 B：一般 Windows 電腦

**先過三關**：型號在認證清單上；開機模式是 UEFI、磁碟是 GPT（舊電腦 Legacy BIOS 不能用 FRD，只能用隨身碟安裝）；不是 S 模式。
單台用 `precheck.ps1` 檢查，一批用 `python psexec_mass_deploy.py --precheck`（只讀不改，結果存成 Excel）。

**1～幾台：`一鍵轉換Flex.bat`**
1. 開檔案改設定區四行：權杖、Wi-Fi 名稱、Wi-Fi 密碼、`$ONLY_TEST`（客戶沒買 CEU 權杖留空，就是不註冊）
2. `$ONLY_TEST = $true`（預設）傳給對方，雙擊、按「是」、輸入 Y。只模擬，桌面會產生 `Flex結果-電腦名稱-時間.zip`（不含權杖與密碼）
3. 看結果：`agent-dryrun.log` 裡要有 SystemChecked、TPMChecked、MemoryChecked、DiskChecked、FilesChecked 五項
4. 都過了，改 `$ONLY_TEST = $false` 再跑一次才會真的轉換

**同網段一批：PsExec**
1. `secrets\config.json` 填權杖、Wi-Fi，`dry_run` 留 `true`；`secrets\devices.txt` 一行一台
2. `python psexec_mass_deploy.py`（或介面「直接遠端部署」）：每台回報結束代碼與記錄最後三行，結果存成 CSV
3. 模擬全過，`dry_run` 改 `false`，先挑 1 台加 `--yes` 跑正式，到 Google 管理控制台確認，再跑全部
4. 連不上時：非網域電腦要先開 `LocalAccountTokenFilterPolicy`，見 `個人電腦遠端部署指南.md`；防火牆要開 445 埠

## 沒有測試機怎麼練

不要拿自己或客戶的正式電腦練正式轉換。建議順序：

1. **Hyper-V 虛擬機練模擬**：這台是 Windows 11 專業版，可以開 Hyper-V，建第 2 代虛擬機（UEFI、GPT）、開虛擬 TPM、
   記憶體 4GB 以上、硬碟 64GB，裝 Windows 11 評估版。在虛擬機裡跑 `一鍵轉換Flex.bat`（模擬），整個流程與記錄都看得到
2. **虛擬機裡試正式轉換**（可選）：虛擬機本來就可以丟，清掉也不心疼。Hyper-V 的 Secure Boot 範本要選
   「Microsoft UEFI Certificate Authority」（跟 Surface 要信任第三方憑證是同一件事）。Google 不支援虛擬機，裝不起來不代表實機有問題
3. **練 Intune 流程**：用 Intune 試用租用戶把虛擬機加入管理，上傳 `flex-DRYRUN-…` 安裝包，看 Intune 回報代碼 0、偵測規則變「已安裝」。
   試用方案的條件以 Microsoft 官方頁面為準
4. **真機**：客戶試點機先跑模擬，拿回 `agent-dryrun.log`、`intune-run.log` 核對

## 機型規矩：只做官方認證的型號

接案第一件事是查 [Google 通過認證的型號清單](https://support.google.com/chromeosflex/answer/11513094)。
Google 官方：裝置未列在認證清單中，就不適用 Chrome Education 或 Chrome Enterprise 支援服務。

| 狀態 | 官方定義 | 我們的做法 |
|---|---|---|
| 通過認證 | 預期可與 ChromeOS Flex 搭配運作 | 可以接，唯一建議部署的狀態 |
| 預期會出現輕微問題 | 可能至少支援基本功能 | 先跟客戶說清楚風險並實測過再決定 |
| 預期會出現重大問題 | 已知有啟動問題等，不建議 | 不要做 |
| 取消認證 | 已達支援終止日期 | 不要做 |

程式沒有寫死機型限制（FRD 對硬體沒有技術性阻擋），這條要靠人守。

## 結束代碼（Intune 與 PsExec 共用，正本在 `intune-install.ps1` 開頭）

| 代碼 | 意思 | 硬碟動過沒 |
|---|---|---|
| 0 | 模擬通過 | 沒有 |
| 1641 | 正式轉換已開始，電腦會重開機 | 有，看 Google 管理控制台 |
| 1618 | 沒插電，Intune 會重試 | 沒有 |
| 10～14 | 不是 UEFI／不是 GPT／磁碟小於 32GB／可用空間不足 10GB／不是 Windows 10、11 | 沒有 |
| 20～23 | 模擬沒跑完五項檢查／agent.exe 回報錯誤／安裝包缺檔／沒有 agent.log | 沒有 |
| 30 | 正式執行前 FRD 自己的檢查沒過，中止 | 沒有 |
| 31 | 正式執行後讀不到記錄 | 不確定，先別關機 |
| 2 | 腳本未預期的錯誤，看 `intune-run.log` | 通常沒有 |

記錄都在那台電腦的 `C:\ProgramData\frd-deploy`：`intune-run.log`（我們的腳本）、`agent-dryrun.log`、`agent.log`（FRD）。

## 檔案地圖

| 檔案 | 用途 |
|---|---|
| `開始操作.bat` → `start-ui.ps1` → `flex-deploy.exe`／`ui_server.py` | 網頁操作介面（只綁 127.0.0.1，一次性通行碼） |
| `intune-install.ps1` | Intune 與 PsExec 共用的安裝腳本（存 UTF-8 BOM，PowerShell 5.1 才讀得懂中文） |
| `intune_flex_packager.py` | 產生 .intunewin |
| `psexec_mass_deploy.py` | 區網直接部署、`--precheck` 預檢 |
| `frd_common.py` | 共用：下載 FRD／Vector、產生 agent.toml、wifi.onc |
| `一鍵轉換Flex.bat` | 單台用，自成一檔、自己下載套件（邏輯與 intune-install.ps1 相同，改一邊要看另一邊） |
| `precheck.ps1` | 單台硬體預檢 |
| `templates\` | agent.toml、wifi.onc、vector.toml 的範本 |
| `secrets\config.json` | 權杖、Wi-Fi 密碼（機密，不進公開 repo） |
| `build-release.ps1` | 打包成給同事下載的 `dist-package\flex-deploy-tool.zip` |
| `build_site_page.py` | 把兩份手冊轉成官網版頁面 |
| `mirror_to_r2.py` | 公司鏡像（版本鎖定用，選用） |

`tools\`（約 2.3GB 官方下載物）、`output\`、`build\`、`dist\` 都是可重生產物，不進 git。
`tools\` 不跟著同步，到現場要帶已經下載過的那台電腦，不然得用學校網路重抓約 1GB。

## 已驗證／還沒驗證

已驗證（離線或假 agent.exe）：
- 打包流程能產出 .intunewin，內含 agent.exe、agent.toml、wifi.onc、vector、intune-install.ps1，SetupFile 正確
- `intune-install.ps1` 以系統身分、從 32 位元程序呼叫，七種情境代碼都正確（2026-10-05）
- PsExec 路線以系統身分跑安裝腳本：模擬 0、正式 1641、沒記錄 23 都正確（2026-10-06，對本機跑，假 agent.exe）
- Wi-Fi 名稱或密碼含 `"`、`\` 時 wifi.onc 仍是合法 JSON

還沒驗證（要等真機）：
- 真 agent.exe 的記錄格式（只確認七個事件名稱字串存在於 agent.exe 裡）
- 真 Intune 派送、Surface Go 實機轉換、Secure Boot 與 BitLocker 實際行為、沒插電 1618

## 踩過的坑

- Vector 的下載網址會擋 Python 預設的 User-Agent（403），`download_file()` 一律帶瀏覽器 UA
- IntuneWinAppUtil 會在專案根目錄留一個 0 byte 的 `Win32` 檔，已加進 `.gitignore`
- 模擬版與正式版安裝包以前同檔名、會互相覆蓋，2026-10-06 起檔名自動標明模式
- PsExec 路線以前用 `-d` 丟出 agent.exe 就不管，「成功」只代表有啟動；2026-10-06 起改跑安裝腳本並等結果

## 機密檔案

`secrets\config.json` 含註冊權杖與 Wi-Fi 密碼，已加進 `.gitignore` 不會進公開 repo，
照全域規則備份進 ClaudeOnly private repo（safezone0619）。權杖不要貼聊天群組。
