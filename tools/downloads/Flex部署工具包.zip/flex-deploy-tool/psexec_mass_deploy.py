"""
intune-flex-deploy 的第二條路：不靠 Intune／任何 MDM，直接用 PsExec 對一批 Windows
裝置遠端執行 FRD，達到「遠端大量部署」的目的。

適合場景：裝置都在同網段／VPN 內、手上有能連 admin share（C$）的帳密，想跳過 MDM
排程週期直接動手。裝置分散在不同網路、沒有直連能力時，還是走 intune_flex_packager.py
那條 Intune 路線比較合適。

流程（每台裝置）：
1. 用 net use 連 \\\\<裝置>\\C$（需要對方系統管理員權限的帳密）
2. robocopy 把 FRD 套件資料夾（含產生好的 agent.toml / wifi.onc）複製過去
3. 用 PsExec 遠端執行 agent.exe（-d 不等它跑完，因為完整部署會重開機）
4. net use /delete 收尾

PsExec 是微軟 Sysinternals 官方工具，第一次執行會自動下載
（https://live.sysinternals.com/PsExec64.exe）。

用法：
    python psexec_mass_deploy.py --config secrets\\config.json --devices secrets\\devices.txt

裝置清單格式見 templates\\devices.example.txt（一行一台，# 開頭是註解）。
secrets\\config.json 除了 enrollment_token/wifi_ssid/wifi_password/dry_run 外，
可選填 remote_admin_user / remote_admin_password（留空就用目前這台電腦登入的帳號權限，
前提是那個帳號在所有目標裝置上都有系統管理員權限）。

⚠ dry_run 是 true 時只會跑模擬測試，不會真的轉機；dry_run 是 false 時這是不可逆操作，
   一定要先用 --yes 以外的方式（也就是先不加 --yes）確認程式會擋下來，跑過測試群組
   沒問題後才加 --yes 對全部裝置執行。
"""

import argparse
import csv
import datetime
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from frd_common import (
    PROJECT_DIR,
    FrdError,
    build_config_files,
    download_file,
    load_config,
    resolve_frd_source_dir,
)

TOOLS_DIR = PROJECT_DIR / "tools"
OUTPUT_DIR = PROJECT_DIR / "output"

# Sysinternals 官方直接下載連結（微軟自家工具，不需要另外安裝）
PSEXEC_URL = "https://live.sysinternals.com/PsExec64.exe"
PSEXEC_PATH = TOOLS_DIR / "PsExec64.exe"

REMOTE_DEPLOY_DIR = r"C$\ProgramData\frd-deploy"  # 對方裝置上的落地路徑（用 admin share 表示）
REMOTE_LOCAL_PATH = r"C:\ProgramData\frd-deploy"  # 同一個路徑，但用來組 PsExec 要執行的本機路徑


def ensure_psexec(log=print) -> Path:
    """第一次執行自動下載官方 PsExec，之後重複使用同一份。"""
    if PSEXEC_PATH.exists():
        return PSEXEC_PATH

    log("[下載] PsExec 尚未取得，從 Sysinternals 官方連結下載...")
    TOOLS_DIR.mkdir(parents=True, exist_ok=True)
    try:
        download_file(PSEXEC_URL, PSEXEC_PATH, log=log)
    except Exception as e:
        raise FrdError(
            f"下載 PsExec 失敗：{e}\n"
            f"可以手動從 https://learn.microsoft.com/sysinternals/downloads/psexec "
            f"下載後放到 {PSEXEC_PATH}"
        )
    log(f"[完成] 已存到 {PSEXEC_PATH}")
    return PSEXEC_PATH


def parse_devices(text: str) -> list[str]:
    """從文字內容解析裝置清單：一行一台，# 開頭當註解。
    網頁介面直接把表格內容丟進來，命令列則是讀檔後丟進來。"""
    devices = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        devices.append(line)
    return devices


def load_devices(devices_path: Path) -> list[str]:
    if not devices_path.exists():
        raise FrdError(
            f"找不到裝置清單：{devices_path}\n"
            f"先複製 templates\\devices.example.txt，填入要部署的電腦名稱/IP，一行一台。"
        )
    devices = parse_devices(devices_path.read_text(encoding="utf-8"))
    if not devices:
        raise FrdError(f"{devices_path} 裡沒有任何裝置，至少要填一台。")
    return devices


def run_cmd(cmd: list[str], timeout: int, success_max_code: int = 0) -> tuple[bool, str]:
    """success_max_code：離場碼 <= 這個值都算成功（robocopy 的 0~7 都是成功，不是只有 0）。"""
    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout
        )
        ok = result.returncode <= success_max_code
        return ok, (result.stdout + result.stderr).strip()
    except subprocess.TimeoutExpired:
        return False, f"逾時（{timeout} 秒）"
    except Exception as e:
        return False, str(e)


def deploy_one_device(
    device: str,
    frd_source_dir: Path,
    psexec: Path,
    remote_user: str,
    remote_password: str,
) -> dict:
    """對單一裝置做「連線→複製→PsExec 執行→收尾」，回傳結果字典。"""
    steps: list[str] = []

    auth_args = []
    if remote_user:
        auth_args = ["/user:" + remote_user, remote_password]

    # 1. 連線 admin share
    ok, msg = run_cmd(["net", "use", f"\\\\{device}\\C$"] + auth_args, timeout=30)
    steps.append(f"連線 C$：{'OK' if ok else 'FAIL - ' + msg}")
    if not ok:
        return {"device": device, "success": False, "steps": steps}

    try:
        # 2. robocopy 整個 FRD 套件資料夾過去（含 agent.toml / wifi.onc）
        remote_dest = f"\\\\{device}\\{REMOTE_DEPLOY_DIR}"
        ok, msg = run_cmd(
            ["robocopy", str(frd_source_dir), remote_dest, "/MIR", "/R:1", "/W:1"],
            timeout=300,
            success_max_code=7,
        )
        steps.append(f"複製套件：{'OK' if ok else 'FAIL - ' + msg}")
        if not ok:
            return {"device": device, "success": False, "steps": steps}

        # 3. PsExec 遠端執行 agent.exe（-d 不等它跑完，完整部署會重開機）
        psexec_cmd = [str(psexec), "-accepteula", f"\\\\{device}"]
        if remote_user:
            psexec_cmd += ["-u", remote_user, "-p", remote_password]
        psexec_cmd += ["-d", "-h", f"{REMOTE_LOCAL_PATH}\\agent.exe"]
        ok, msg = run_cmd(psexec_cmd, timeout=120)
        steps.append(f"PsExec 執行：{'OK' if ok else 'FAIL - ' + msg}")

        return {"device": device, "success": ok, "steps": steps}
    finally:
        # 4. 收尾，斷開連線
        run_cmd(["net", "use", f"\\\\{device}\\C$", "/delete", "/y"], timeout=15)


def run_mass_deploy(
    config: dict, devices: list[str], parallel: int = 5, log=print
) -> list[dict]:
    """完整的 PsExec 大量部署流程。命令列與網頁介面共用這個函式。

    每台裝置完成時就 log 一行，介面才能即時更新成功/失敗計數，
    而不是等全部跑完才一次噴出來。
    """
    frd_source_dir = resolve_frd_source_dir(config, log=log)
    build_config_files(config, frd_source_dir, log=log)
    psexec = ensure_psexec(log=log)

    remote_user = config.get("remote_admin_user", "")
    remote_password = config.get("remote_admin_password", "")

    mode = "模擬測試（dry_run）" if config.get("dry_run", True) else "正式部署（不可逆）"
    log(f"[開始] {mode}，共 {len(devices)} 台裝置，同時處理 {parallel} 台")

    results = []
    with ThreadPoolExecutor(max_workers=parallel) as pool:
        futures = {
            pool.submit(
                deploy_one_device, device, frd_source_dir, psexec, remote_user, remote_password
            ): device
            for device in devices
        }
        for future in as_completed(futures):
            r = future.result()
            results.append(r)
            status = "成功" if r["success"] else "失敗"
            log(f"[{status}] {r['device']}：{' | '.join(r['steps'])}")

    ok_count = sum(1 for r in results if r["success"])
    log(f"[完成] {ok_count}/{len(results)} 台成功")
    return results


def write_summary_csv(results: list[dict]) -> Path:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    out_path = OUTPUT_DIR / f"psexec-deploy-result-{ts}.csv"
    with out_path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["裝置", "成功", "細節"])
        for r in results:
            writer.writerow([r["device"], "是" if r["success"] else "否", " | ".join(r["steps"])])
    return out_path


def main():
    parser = argparse.ArgumentParser(
        description="不靠 Intune，直接用 PsExec 對一批 Windows 裝置遠端跑 FRD"
    )
    parser.add_argument(
        "--config", type=Path, default=PROJECT_DIR / "secrets" / "config.json"
    )
    parser.add_argument(
        "--devices", type=Path, default=PROJECT_DIR / "secrets" / "devices.txt"
    )
    parser.add_argument(
        "--parallel", type=int, default=5, help="同時處理幾台裝置（預設 5）"
    )
    parser.add_argument(
        "--yes",
        action="store_true",
        help="dry_run 為 false（真的執行轉機）時必須加這個旗標才會動手，防止手滑大量誤觸",
    )
    args = parser.parse_args()

    try:
        config = load_config(args.config)
        devices = load_devices(args.devices)

        if not config.get("dry_run", True) and not args.yes:
            sys.exit(
                "secrets\\config.json 的 dry_run 是 false（會真的把裝置轉成 ChromeOS Flex，"
                "不可逆），但沒有加 --yes。\n"
                "先確認：已經對測試群組跑過 dry_run=true 沒問題了嗎？\n"
                "確定要對這份清單裡的裝置動手，再加 --yes 重跑一次這條指令。"
            )

        results = run_mass_deploy(config, devices, args.parallel)
    except FrdError as e:
        sys.exit(str(e))

    csv_path = write_summary_csv(results)
    print(f"[報告] 完整結果已寫入 {csv_path}")

    if config.get("dry_run", True):
        print(
            "\n這次是模擬測試，裝置不會真的轉機。去每台裝置檢查 "
            f"{REMOTE_LOCAL_PATH}\\agent.log 裡的 InstallSkipped 記錄，"
            "確認沒問題後把 secrets\\config.json 的 dry_run 改 false，"
            "先對測試群組（1~2 台裝置清單）加 --yes 跑一次真的部署，"
            "沒問題再把裝置清單擴大到全部。"
        )


if __name__ == "__main__":
    main()
