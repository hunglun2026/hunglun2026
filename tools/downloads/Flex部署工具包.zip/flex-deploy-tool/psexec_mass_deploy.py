"""
intune-flex-deploy 的第二條路：不靠 Intune／任何 MDM，直接用 PsExec 對一批 Windows
裝置遠端執行 FRD，達到「遠端大量部署」的目的。

適合場景：裝置都在同網段／VPN 內、手上有能連 admin share（C$）的帳密，想跳過 MDM
排程週期直接動手。裝置分散在不同網路、沒有直連能力時，還是走 intune_flex_packager.py
那條 Intune 路線比較合適。

流程（每台裝置）：
1. 用 net use 連 \\\\<裝置>\\C$（需要對方系統管理員權限的帳密）
2. robocopy 把 FRD 套件資料夾（含產生好的 agent.toml / wifi.onc / intune-install.ps1）複製過去
3. 用 PsExec 以系統身分跑 intune-install.ps1（跟 Intune 同一支：先模擬、通過才正式），
   等它跑完，照代碼表回報每台結果
4. net use /delete 收尾

PsExec 是微軟 Sysinternals 官方工具，第一次執行會自動下載
（https://live.sysinternals.com/PsExec64.exe）。

用法：
    python psexec_mass_deploy.py --config secrets\\config.json --devices secrets\\devices.txt

裝置清單格式見 templates\\devices.example.txt（一行一台，# 開頭是註解）。
secrets\\config.json 除了 enrollment_token/wifi_ssid/wifi_password/dry_run 外，
可選填 remote_admin_user / remote_admin_password（留空就用目前這台電腦登入的帳號權限，
前提是那個帳號在所有目標裝置上都有系統管理員權限）。

⚠ dry_run 是 true 時只會跑模擬測試，不會真的轉機；dry_run 是 false 時這是不可逆操作，
   一定要先用 --yes 以外的方式（也就是先不加 --yes）確認程式會擋下來，跑過測試群組
   沒問題後才加 --yes 對全部裝置執行。
"""

import argparse
import base64
import csv
import datetime
import json
import re
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from frd_common import (
    INSTALL_SCRIPT,
    PROJECT_DIR,
    FrdError,
    build_config_files,
    download_file,
    load_config,
    resolve_frd_source_dir,
)

TOOLS_DIR = PROJECT_DIR / "tools"
OUTPUT_DIR = PROJECT_DIR / "output"

# Sysinternals 官方直接下載連結（微軟自家工具，不需要另外安裝）
PSEXEC_URL = "https://live.sysinternals.com/PsExec64.exe"
PSEXEC_PATH = TOOLS_DIR / "PsExec64.exe"

REMOTE_DEPLOY_DIR = r"C$\ProgramData\frd-deploy"  # 對方裝置上的落地路徑（用 admin share 表示）
REMOTE_LOCAL_PATH = r"C:\ProgramData\frd-deploy"  # 同一個路徑，但用來組 PsExec 要執行的本機路徑

# intune-install.ps1 的結束代碼（代碼表正本在腳本開頭，改那邊要一起改這裡）
# 值：（算不算成功, 中文說明）
INSTALL_CODES = {
    0: (True, "模擬通過，硬碟沒動"),
    1641: (True, "正式轉換已開始，電腦約 2 分鐘內自己重開機進 Flex 安裝；成功與否看 Google 管理控制台"),
    1618: (False, "沒插電，插電後再跑一次"),
    2: (False, "腳本發生未預期的錯誤，看 intune-run.log"),
    10: (False, "開機模式不是 UEFI"),
    11: (False, "系統磁碟不是 GPT"),
    12: (False, "系統磁碟小於 32GB"),
    13: (False, "C 槽可用空間不足 10GB"),
    14: (False, "不是 Windows 10/11"),
    20: (False, "模擬沒跑完五項官方檢查，看 agent-dryrun.log"),
    21: (False, "模擬時 agent.exe 回報錯誤"),
    22: (False, "套件裡找不到 agent.exe 或 agent.toml"),
    23: (False, "模擬沒產生 agent.log（記錄器沒裝好）"),
    30: (False, "正式執行前檢查沒過，FRD 中止，硬碟沒被動到"),
    31: (False, "正式執行後讀不到記錄，無法判斷，先別關機"),
}
# 模擬加正式最久要多久，官方沒寫；Intune 那邊設 120 分，這裡跟著用
SCRIPT_TIMEOUT = 7200


def ensure_psexec(log=print) -> Path:
    """第一次執行自動下載官方 PsExec，之後重複使用同一份。"""
    if PSEXEC_PATH.exists():
        return PSEXEC_PATH

    log("[下載] PsExec 尚未取得，從 Sysinternals 官方連結下載...")
    TOOLS_DIR.mkdir(parents=True, exist_ok=True)
    try:
        download_file(PSEXEC_URL, PSEXEC_PATH, log=log)
    except Exception as e:
        raise FrdError(
            f"下載 PsExec 失敗：{e}\n"
            f"可以手動從 https://learn.microsoft.com/sysinternals/downloads/psexec "
            f"下載後放到 {PSEXEC_PATH}"
        )
    log(f"[完成] 已存到 {PSEXEC_PATH}")
    return PSEXEC_PATH


def parse_devices(text: str) -> list[str]:
    """從文字內容解析裝置清單：一行一台，# 開頭當註解。
    網頁介面直接把表格內容丟進來，命令列則是讀檔後丟進來。"""
    devices = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        devices.append(line)
    return devices


def load_devices(devices_path: Path) -> list[str]:
    if not devices_path.exists():
        raise FrdError(
            f"找不到裝置清單：{devices_path}\n"
            f"先複製 templates\\devices.example.txt，填入要部署的電腦名稱/IP，一行一台。"
        )
    devices = parse_devices(devices_path.read_text(encoding="utf-8"))
    if not devices:
        raise FrdError(f"{devices_path} 裡沒有任何裝置，至少要填一台。")
    return devices


def _decode(data: bytes) -> str:
    """net use／PsExec 轉回來的遠端輸出是中文 Windows 的 cp950，不是 UTF-8。
    用 text=True 交給 Python 猜編碼，猜錯時讀取執行緒會直接崩潰、輸出整段遺失。"""
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("mbcs", errors="replace")


def run_cmd(cmd: list[str], timeout: int, success_max_code: int = 0) -> tuple[bool, str]:
    """success_max_code：離場碼 <= 這個值都算成功（robocopy 的 0~7 都是成功，不是只有 0）。"""
    try:
        # stdin 給 DEVNULL：PsExec 遠端跑 powershell 時會等輸入，不給會卡到逾時
        result = subprocess.run(
            cmd, capture_output=True, timeout=timeout,
            stdin=subprocess.DEVNULL,
        )
        ok = result.returncode <= success_max_code
        return ok, (_decode(result.stdout) + _decode(result.stderr)).strip()
    except subprocess.TimeoutExpired:
        return False, f"逾時（{timeout} 秒）"
    except Exception as e:
        return False, str(e)


def run_cmd_code(cmd: list[str], timeout: int) -> tuple[int | None, str]:
    """跟 run_cmd 一樣，但回傳原始離場碼（逾時或執行不了是 None），給要查代碼表的地方用。"""
    try:
        result = subprocess.run(
            cmd, capture_output=True, timeout=timeout, stdin=subprocess.DEVNULL,
        )
        return result.returncode, (_decode(result.stdout) + _decode(result.stderr)).strip()
    except subprocess.TimeoutExpired:
        return None, f"逾時（{timeout} 秒）"
    except Exception as e:
        return None, str(e)


def read_remote_log_tail(device: str, lines: int = 3) -> str:
    """從 C$ 讀回遠端 intune-run.log 最後幾行，報告裡才看得到每台停在哪。"""
    path = Path(f"\\\\{device}\\{REMOTE_DEPLOY_DIR}\\intune-run.log")
    try:
        text = path.read_text(encoding="utf-8-sig", errors="replace")
    except OSError:
        return ""
    return " / ".join(text.strip().splitlines()[-lines:])


def deploy_one_device(
    device: str,
    frd_source_dir: Path,
    psexec: Path,
    remote_user: str,
    remote_password: str,
) -> dict:
    """對單一裝置做「連線→複製→PsExec 執行→收尾」，回傳結果字典。"""
    steps: list[str] = []

    auth_args = []
    if remote_user:
        auth_args = ["/user:" + remote_user, remote_password]

    # 1. 連線 admin share
    ok, msg = run_cmd(["net", "use", f"\\\\{device}\\C$"] + auth_args, timeout=30)
    if not ok:
        hint = ""
        if "拒絕存取" in msg or "Access is denied" in msg or "5" in msg.split():
            hint = (
                " ← 疑似非網域機器的 UAC 遠端限制：目標裝置若不是網域環境（如個人筆電、"
                "工作群組），用非內建 Administrator 的系統管理員帳號連 admin share 預設會被擋。"
                "要在目標裝置上執行一次（可本機或先用別的遠端方式）："
                r" reg add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"
                r" /v LocalAccountTokenFilterPolicy /t REG_DWORD /d 1 /f"
                "，做一次就好，之後才能被 PsExec 連。"
            )
        steps.append(f"連線 C$：FAIL - {msg}{hint}")
        return {"device": device, "success": False, "steps": steps}
    steps.append("連線 C$：OK")

    try:
        # 2. robocopy 整個 FRD 套件資料夾過去（含 agent.toml / wifi.onc）
        remote_dest = f"\\\\{device}\\{REMOTE_DEPLOY_DIR}"
        ok, msg = run_cmd(
            ["robocopy", str(frd_source_dir), remote_dest, "/MIR", "/R:1", "/W:1"],
            timeout=1800,  # 套件約 1GB，原本 300 秒在 Wi-Fi 或慢的網段不夠
            success_max_code=7,
        )
        steps.append(f"複製套件：{'OK' if ok else 'FAIL - ' + msg}")
        if not ok:
            return {"device": device, "success": False, "steps": steps}

        # 3. PsExec 用系統身分跑 intune-install.ps1，等它跑完看結束代碼。
        #    跟 Intune 路線同一支腳本：檢查硬體、模擬、dry_run=false 才正式，結果用同一張代碼表。
        #    （2026-10-06 前是 -d 直接丟 agent.exe 不等，「成功」只代表程式有啟動，模擬過沒過看不到）
        psexec_cmd = [str(psexec), "-accepteula", "-nobanner", f"\\\\{device}"]
        if remote_user:
            psexec_cmd += ["-u", remote_user, "-p", remote_password]
        psexec_cmd += ["-s", "powershell.exe", "-NoProfile", "-NonInteractive",
                       "-ExecutionPolicy", "Bypass", "-File", f"{REMOTE_LOCAL_PATH}\\intune-install.ps1"]
        code, msg = run_cmd_code(psexec_cmd, timeout=SCRIPT_TIMEOUT)
        if code in INSTALL_CODES:
            ok, meaning = INSTALL_CODES[code]
            steps.append(f"安裝腳本：代碼 {code}，{meaning}")
        elif code is None:
            ok = False
            steps.append(f"安裝腳本：{msg}。正式部署的話可能已經開始轉換並重開機，先看 Google 管理控制台")
        else:
            ok = False
            steps.append(f"安裝腳本：代碼 {code}（不在代碼表，多半是 PsExec 本身的錯誤）{msg[-300:]}")
        tail = read_remote_log_tail(device)
        if tail:
            steps.append(f"記錄：{tail}")

        return {"device": device, "success": ok, "steps": steps}
    finally:
        # 4. 收尾，斷開連線
        run_cmd(["net", "use", f"\\\\{device}\\C$", "/delete", "/y"], timeout=15)


def run_mass_deploy(
    config: dict, devices: list[str], parallel: int = 5, log=print
) -> list[dict]:
    """完整的 PsExec 大量部署流程。命令列與網頁介面共用這個函式。

    每台裝置完成時就 log 一行，介面才能即時更新成功/失敗計數，
    而不是等全部跑完才一次噴出來。
    """
    frd_source_dir = resolve_frd_source_dir(config, log=log)
    build_config_files(config, frd_source_dir, log=log)
    if "sidecar_logger_exe" not in (frd_source_dir / "agent.toml").read_text(encoding="utf-8"):
        raise FrdError("套件裡沒有記錄器（vector.exe），安裝腳本無法判斷結果，已停止。看上面 Vector 下載失敗的原因。")
    shutil.copy2(INSTALL_SCRIPT, frd_source_dir / INSTALL_SCRIPT.name)
    psexec = ensure_psexec(log=log)

    remote_user = config.get("remote_admin_user", "")
    remote_password = config.get("remote_admin_password", "")

    mode = "模擬測試（dry_run）" if config.get("dry_run", True) else "正式部署（不可逆）"
    log(f"[開始] {mode}，共 {len(devices)} 台裝置，同時處理 {parallel} 台")

    results = []
    with ThreadPoolExecutor(max_workers=parallel) as pool:
        futures = {
            pool.submit(
                deploy_one_device, device, frd_source_dir, psexec, remote_user, remote_password
            ): device
            for device in devices
        }
        for future in as_completed(futures):
            r = future.result()
            results.append(r)
            status = "成功" if r["success"] else "失敗"
            log(f"[{status}] {r['device']}：{' | '.join(r['steps'])}")

    ok_count = sum(1 for r in results if r["success"])
    log(f"[完成] {ok_count}/{len(results)} 台成功")
    return results


PRECHECK_SCRIPT = PROJECT_DIR / "precheck.ps1"


def judge_precheck(info: dict) -> list[str]:
    """官方硬體門檻，跟 precheck.ps1 單台模式的判斷一致。"""
    fail = []
    if info.get("firmware") != "UEFI":
        fail.append(f"開機模式不是 UEFI（{info.get('firmware')}）")
    if info.get("partition") != "GPT":
        fail.append(f"磁碟不是 GPT（{info.get('partition')}）")
    if (info.get("disk_gb") or 0) < 32:
        fail.append("磁碟小於 32GB")
    # 官方寫 5GB，但同頁「已知問題：部分裝置需要 9GB 可用空間」
    if (info.get("free_gb") or 0) < 9:
        fail.append("可用空間小於 9GB（官方已知部分裝置需要 9GB）")
    if not re.search(r"Windows 1[01]", info.get("os") or ""):
        fail.append("不是 Windows 10/11")
    return fail


def precheck_one_device(
    device: str, psexec: Path, remote_user: str, remote_password: str
) -> dict:
    """PsExec 遠端跑 precheck.ps1（EncodedCommand 帶過去，不用先複製檔案），只讀不改。
    結果由遠端寫進 C:\\ProgramData\\frd-precheck.json，再從 C$ 讀回來，讀完就刪。"""
    share = f"\\\\{device}\\C$"
    auth = ["/user:" + remote_user, remote_password] if remote_user else []
    ok, msg = run_cmd(["net", "use", share] + auth, timeout=30)
    if not ok:
        return {"device": device, "status": "連不上", "info": {},
                "reasons": [f"連線 C$ 失敗：{msg}（非網域機器見 個人電腦遠端部署指南.md）"]}

    result_file = Path(share) / "ProgramData" / "frd-precheck.json"
    try:
        result_file.unlink(missing_ok=True)  # 清掉上次留下的，免得讀到舊結果
        script = "$FrdJson = $true\n" + PRECHECK_SCRIPT.read_text(encoding="utf-8-sig")
        encoded = base64.b64encode(script.encode("utf-16-le")).decode("ascii")
        cmd = [str(psexec), "-accepteula", "-nobanner", f"\\\\{device}"]
        if remote_user:
            cmd += ["-u", remote_user, "-p", remote_password]
        cmd += ["-h", "powershell", "-NoProfile", "-NonInteractive",
                "-ExecutionPolicy", "Bypass", "-EncodedCommand", encoded]
        _, msg = run_cmd(cmd, timeout=90)

        if not result_file.exists():
            return {"device": device, "status": "連不上", "info": {},
                    "reasons": [f"腳本沒產生結果：{msg[-300:]}"]}
        info = json.loads(result_file.read_text(encoding="ascii"))
        result_file.unlink(missing_ok=True)
        fail = judge_precheck(info)
        return {"device": device, "status": "不合格" if fail else "合格",
                "reasons": fail, "info": info}
    finally:
        run_cmd(["net", "use", share, "/delete", "/y"], timeout=15)


def run_precheck(config: dict, devices: list[str], parallel: int = 5, log=print) -> list[dict]:
    psexec = ensure_psexec(log=log)
    remote_user = config.get("remote_admin_user", "")
    remote_password = config.get("remote_admin_password", "")
    log(f"[預檢] 共 {len(devices)} 台，只讀資訊不改設定")

    results = []
    with ThreadPoolExecutor(max_workers=parallel) as pool:
        futures = [
            pool.submit(precheck_one_device, d, psexec, remote_user, remote_password)
            for d in devices
        ]
        for future in as_completed(futures):
            r = future.result()
            results.append(r)
            detail = "；".join(r["reasons"]) or r["info"].get("model", "")
            log(f"[{r['status']}] {r['device']}：{detail}")

    ok = sum(1 for r in results if r["status"] == "合格")
    log(f"[完成] 硬體合格 {ok}/{len(results)} 台，型號還要人工比對認證清單")
    return results


def write_precheck_xlsx(results: list[dict]) -> Path:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    out_path = OUTPUT_DIR / f"precheck-{ts}.xlsx"

    wb = Workbook()
    ws = wb.active
    ws.title = "部署前檢查"
    headers = ["裝置", "結果", "不合格原因", "廠牌型號", "認證清單狀態（人工填）",
               "作業系統", "開機模式", "磁碟格式", "磁碟GB", "可用GB", "TPM"]
    ws.append(headers)
    for c in ws[1]:
        c.font = Font(bold=True)
    fills = {"合格": "C6EFCE", "不合格": "FFC7CE", "連不上": "FFEB9C"}
    for r in sorted(results, key=lambda x: x["device"]):
        i = r["info"]
        ws.append([
            r["device"], r["status"], "；".join(r["reasons"]), i.get("model", ""), "",
            i.get("os", ""), i.get("firmware", ""), i.get("partition", ""),
            i.get("disk_gb", ""), i.get("free_gb", ""),
            ("有" if i.get("tpm") else "查不到") if i else "",
        ])
        ws.cell(ws.max_row, 2).fill = PatternFill("solid", fgColor=fills[r["status"]])
    ws.freeze_panes = "B2"
    for col, width in zip("ABCDEFGHIJK", [16, 8, 40, 32, 22, 30, 10, 10, 8, 8, 8]):
        ws.column_dimensions[col].width = width
    wb.save(out_path)
    return out_path


def write_summary_csv(results: list[dict]) -> Path:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    out_path = OUTPUT_DIR / f"psexec-deploy-result-{ts}.csv"
    with out_path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["裝置", "成功", "細節"])
        for r in results:
            writer.writerow([r["device"], "是" if r["success"] else "否", " | ".join(r["steps"])])
    return out_path


def main():
    parser = argparse.ArgumentParser(
        description="不靠 Intune，直接用 PsExec 對一批 Windows 裝置遠端跑 FRD"
    )
    parser.add_argument(
        "--config", type=Path, default=PROJECT_DIR / "secrets" / "config.json"
    )
    parser.add_argument(
        "--devices", type=Path, default=PROJECT_DIR / "secrets" / "devices.txt"
    )
    parser.add_argument(
        "--parallel", type=int, default=5, help="同時處理幾台裝置（預設 5）"
    )
    parser.add_argument(
        "--yes",
        action="store_true",
        help="dry_run 為 false（真的執行轉機）時必須加這個旗標才會動手，防止手滑大量誤觸",
    )
    parser.add_argument(
        "--precheck",
        action="store_true",
        help="只檢查每台是否符合 FRD 硬體條件（UEFI/GPT/容量/系統版本），不部署，結果存 xlsx",
    )
    args = parser.parse_args()

    if args.precheck:
        # 預檢只需要遠端帳密，不走 load_config（它會要求註冊權杖，沒 CEU 的客戶也該能預檢）
        try:
            config = {}
            if args.config.exists():
                config = json.loads(args.config.read_text(encoding="utf-8"))
            results = run_precheck(config, load_devices(args.devices), args.parallel)
        except FrdError as e:
            sys.exit(str(e))
        print(f"[報告] {write_precheck_xlsx(results)}")
        return

    try:
        config = load_config(args.config)
        devices = load_devices(args.devices)

        if not config.get("dry_run", True) and not args.yes:
            sys.exit(
                "secrets\\config.json 的 dry_run 是 false（會真的把裝置轉成 ChromeOS Flex，"
                "不可逆），但沒有加 --yes。\n"
                "先確認：已經對測試群組跑過 dry_run=true 沒問題了嗎？\n"
                "確定要對這份清單裡的裝置動手，再加 --yes 重跑一次這條指令。"
            )

        results = run_mass_deploy(config, devices, args.parallel)
    except FrdError as e:
        sys.exit(str(e))

    csv_path = write_summary_csv(results)
    print(f"[報告] 完整結果已寫入 {csv_path}")

    if config.get("dry_run", True):
        print(
            "\n這次是模擬測試，裝置不會真的轉機。去每台裝置檢查 "
            f"{REMOTE_LOCAL_PATH}\\agent.log：五個檢查事件（SystemChecked、TPMChecked、MemoryChecked、"
            "DiskChecked、FilesChecked）都要跑完、沒有錯誤。InstallSkipped 在模擬結束或檢查沒過都會出現，不能單看它；"
            "確認沒問題後把 secrets\\config.json 的 dry_run 改 false，"
            "先對測試群組（1~2 台裝置清單）加 --yes 跑一次真的部署，"
            "沒問題再把裝置清單擴大到全部。"
        )


if __name__ == "__main__":
    main()
