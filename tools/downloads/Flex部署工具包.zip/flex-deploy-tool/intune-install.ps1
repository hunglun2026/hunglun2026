﻿# Intune 用的 ChromeOS Flex 安裝腳本（Win32 應用程式的安裝命令）
# 安裝命令：%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\intune-install.ps1
# 以「系統」身分執行。流程照 Google 官方 samples/deployment.ps1，另加檢查、先模擬再正式。
#
# 模式看安裝包裡 agent.toml 的 dry_run：
#   true  ＝只模擬，通過就留 dryrun-ok.txt（偵測規則用這個檔）
#   false ＝先模擬，通過才正式轉換，開始轉換就留 install-started.txt（偵測規則用這個檔）
#
# 結束代碼（Intune 後台「裝置安裝狀態」看得到）：
#   0     成功：模擬通過（只模擬的版本）
#   1641  成功：正式轉換已開始，Intune 預設把 1641 當「強制重新開機」，重開後進入 ChromeOS Flex 安裝
#         （Google 官方：agent.exe 約 2 分鐘內會自己重開機，常常來不及回報，Intune 就停在「安裝中」，以 Google 管理控制台為準）
#   1618  沒插電，Intune 預設把 1618 當「重試」（官方：重試三次、間隔五分鐘，之後算失敗）
#   10 不是 UEFI   11 不是 GPT   12 磁碟小於 32GB   13 可用空間不足   14 不是 Windows 10/11
#   20 模擬沒跑完五項官方檢查   21 模擬時 agent.exe 回報錯誤   22 安裝包裡找不到 agent.exe 或 agent.toml
#   30 正式執行前檢查沒過，FRD 自己中止，硬碟沒被動到   31 正式執行後讀不到記錄，無法判斷
#   2  腳本發生未預期的錯誤（intune-run.log 會寫是第幾行、什麼錯誤）
# 記錄都在 C:\ProgramData\frd-deploy：intune-run.log（本腳本）、agent-dryrun.log、agent.log（FRD）

$ErrorActionPreference = 'Stop'

# Intune 有時用 32 位元 PowerShell 執行，磁碟與分割區查詢可能被導向，改用 64 位元重跑自己
if ([Environment]::Is64BitOperatingSystem -and -not [Environment]::Is64BitProcess) {
    $ps64 = Join-Path $env:SystemRoot 'Sysnative\WindowsPowerShell\v1.0\powershell.exe'
    & $ps64 -NoProfile -ExecutionPolicy Bypass -File $PSCommandPath
    exit $LASTEXITCODE
}

$SRC = $PSScriptRoot
$WORK = Join-Path $env:ProgramData 'frd-deploy'
if ($env:FRD_TEST_DIR) { $WORK = $env:FRD_TEST_DIR }   # 測試用，正式不要設
$MIN_FREE_GB = 10   # 官方已知問題「部分裝置需要 9GB」＋複製安裝包約 1GB（安裝包本身已經被 Intune 下載到這台）

New-Item -ItemType Directory -Force -Path $WORK | Out-Null
$runLog = Join-Path $WORK 'intune-run.log'
function Log([string]$m) { Add-Content -LiteralPath $runLog -Value ('{0} {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $m) -Encoding UTF8 }
function Quit([int]$code, [string]$msg) { Log "結束代碼 $code：$msg"; exit $code }
# 沒預期到的錯誤（例如系統查詢失敗）：記進 intune-run.log 並回 2，不然 Intune 只看到代碼 1、什麼線索都沒有
trap { Log ("未預期的錯誤（第 {0} 行）：{1}" -f $_.InvocationInfo.ScriptLineNumber, $_.Exception.Message); Quit 2 '腳本發生未預期的錯誤，看上一行；發生在檢查或複製階段時硬碟沒被動到' }

Log '===== 開始 ====='
$okMark = Join-Path $WORK 'dryrun-ok.txt'
$startMark = Join-Path $WORK 'install-started.txt'
Remove-Item $okMark, $startMark -ErrorAction SilentlyContinue

# ----- 1. 檢查硬體 -----
$os = (Get-CimInstance Win32_OperatingSystem).Caption
$cs = Get-CimInstance Win32_ComputerSystem
$disk = Get-Partition -DriveLetter C | Get-Disk
$freeGB = [math]::Round((Get-PSDrive C).Free / 1GB, 1)
Log ("型號：{0} {1}｜系統：{2}｜開機模式：{3}｜磁碟：{4}，{5}GB，可用 {6}GB" -f $cs.Manufacturer, $cs.Model, $os, $env:firmware_type, $disk.PartitionStyle, [math]::Round($disk.Size / 1GB), $freeGB)
if ($os -notmatch 'Windows 1[01]') { Quit 14 '只支援 Windows 10 或 11' }
if ($env:firmware_type -ne 'UEFI') { Quit 10 '開機模式不是 UEFI' }
if ("$($disk.PartitionStyle)" -ne 'GPT') { Quit 11 '系統磁碟不是 GPT' }
if ($disk.Size / 1GB -lt 32) { Quit 12 '系統磁碟小於 32GB' }
if ($freeGB -lt $MIN_FREE_GB) { Quit 13 "C 槽可用空間 $freeGB GB，至少要 $MIN_FREE_GB GB" }
$battery = Get-CimInstance -Namespace root/wmi -ClassName BatteryStatus -ErrorAction SilentlyContinue | Select-Object -First 1
if ($battery -and -not $battery.PowerOnline) { Quit 1618 '沒插電，等 Intune 重試' }

# ----- 2. 把安裝包複製到固定資料夾（Intune 的暫存資料夾跑完會被清掉，記錄要留下來）-----
if (-not (Test-Path (Join-Path $SRC 'agent.exe')) -or -not (Test-Path (Join-Path $SRC 'agent.toml'))) { Quit 22 '安裝包裡找不到 agent.exe 或 agent.toml' }
if ($SRC -ne $WORK) {
    Get-ChildItem -LiteralPath $SRC -Force | Where-Object { $_.Name -ne 'intune-run.log' } | Copy-Item -Destination $WORK -Recurse -Force
}
$toml = Join-Path $WORK 'agent.toml'
$baseToml = [IO.File]::ReadAllText($toml)
$onlyTest = $baseToml -match '(?m)^\s*dry_run\s*=\s*true'
Log ('模式：' + $(if ($onlyTest) { '只模擬' } else { '模擬通過後正式轉換' }))
$utf8 = New-Object System.Text.UTF8Encoding($false)
function Set-DryRun([bool]$on) {
    $t = $baseToml -replace '(?m)^\s*dry_run\s*=\s*(true|false)', ('dry_run = ' + $on.ToString().ToLower())
    [IO.File]::WriteAllText($toml, $t, $utf8)
}
$log = Join-Path $WORK 'agent.log'
function Read-Log { if (Test-Path $log) { Get-Content $log -Raw -Encoding UTF8 } else { '' } }

# ----- 3. 模擬測試（官方事件表 answer/16390092：InstallSkipped 不代表成功，要看五個 Checked）-----
Set-DryRun $true
if (Test-Path $log) { Remove-Item $log }
Push-Location $WORK
& .\agent.exe
$code = $LASTEXITCODE
Pop-Location
$dryLog = Read-Log
if (Test-Path $log) { Move-Item $log (Join-Path $WORK 'agent-dryrun.log') -Force }
$checks = 'SystemChecked', 'TPMChecked', 'MemoryChecked', 'DiskChecked', 'FilesChecked'
$seen = @($checks | Where-Object { $dryLog -match $_ })
Log ('模擬：官方檢查 {0}/5（{1}），agent.exe 代碼 {2}' -f $seen.Count, ($seen -join '、'), $code)
if ($dryLog -and $seen.Count -lt 5) { Quit 20 '模擬沒跑完五項官方檢查，看 agent-dryrun.log' }
if ($code -ne 0) { Quit 21 "模擬時 agent.exe 回報錯誤（代碼 $code）" }
Set-Content -LiteralPath $okMark -Value (Get-Date -Format s) -Encoding ASCII
if ($onlyTest) { Quit 0 '模擬通過' }

# ----- 4. 正式轉換（FRD 正式模式會再檢查一次，沒過就中止、不動硬碟）-----
Set-DryRun $false
Push-Location $WORK
& .\agent.exe
$code = $LASTEXITCODE
Pop-Location
$realLog = Read-Log
if ($realLog -match 'InstallStarted') {
    Set-Content -LiteralPath $startMark -Value (Get-Date -Format s) -Encoding ASCII
    # FRD 已經在 Windows 裡做完清 TPM、建分割區、複製檔案、設定開機；回傳 1641 讓 Intune 重新開機
    Quit 1641 '正式轉換已開始，交給 Intune 重新開機後安裝 ChromeOS Flex；成功與否看 Google 管理控制台'
}
if ($realLog -match 'InstallSkipped') { Quit 30 '正式執行前檢查沒過，FRD 中止，硬碟沒被動到，看 agent.log' }
Quit 31 "讀不到正式執行記錄（agent.exe 代碼 $code），無法判斷"
