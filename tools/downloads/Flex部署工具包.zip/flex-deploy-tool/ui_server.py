"""
intune-flex-deploy 網頁操作介面（本機服務）

為什麼不做成 Cloudflare Worker 那種純網址版：這個工具要執行 IntuneWinAppUtil.exe、
PsExec、robocopy、net use，還要處理 1 GB 檔案與區網 SMB 分享。瀏覽器沙箱一律做不到，
所以介面長得像網頁，實際上是本機跑一個小服務，瀏覽器只是畫面。

安全設計（這個工具會清空整台電腦的 Windows，又持有註冊權杖、Wi-Fi 密碼、
遠端系統管理員帳密）：
- 只綁 127.0.0.1，不綁 0.0.0.0，區網上的其他人連不到
- 啟動時產生隨機 session token，所有 API 都要帶。防的是同一台機器上的其他程序
- 畫面上那道密碼閘只是「防止有人經過誤按」，不是資安機制，別把它當防線

用法：
    python ui_server.py            自動選 port、開瀏覽器
    python ui_server.py --port 8760 --no-browser
"""

import argparse
import json
import mimetypes
import queue
import secrets
import threading
import time
import traceback
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import frd_common
from frd_common import PROJECT_DIR, FrdError, find_unfilled_fields
from intune_flex_packager import run_packaging
from psexec_mass_deploy import parse_devices, run_mass_deploy, write_summary_csv

UI_DIR = PROJECT_DIR / "ui"
OUTPUT_DIR = PROJECT_DIR / "output"
CONFIG_PATH = PROJECT_DIR / "secrets" / "config.json"

SESSION_TOKEN = secrets.token_urlsafe(24)

# UI 只負責這幾個欄位，其他欄位（frd_source_dir 之類）
# 保留設定檔裡原本的值，不被介面覆蓋掉
UI_MANAGED_KEYS = [
    "enrollment_token",
    "wifi_ssid",
    "wifi_password",
    "dry_run",
    "enable_logging",
    "remote_admin_user",
    "remote_admin_password",
    "download_source",
]
SECRET_KEYS = {"enrollment_token", "wifi_password", "remote_admin_password"}


class JobRunner:
    """同一時間只跑一項工作，執行過程的每一行記錄推給所有訂閱中的瀏覽器。

    用佇列而不是直接寫入回應，是因為工作跑在背景執行緒，
    而 SSE 連線可能中途斷掉重連，兩者要解耦。
    """

    def __init__(self):
        self._lock = threading.Lock()
        self._subscribers: list[queue.Queue] = []
        self._sub_lock = threading.Lock()
        self.current_job: str | None = None
        self.last_result: dict = {}

    def subscribe(self) -> queue.Queue:
        q: queue.Queue = queue.Queue()
        with self._sub_lock:
            self._subscribers.append(q)
        return q

    def unsubscribe(self, q: queue.Queue) -> None:
        with self._sub_lock:
            if q in self._subscribers:
                self._subscribers.remove(q)

    def emit(self, event: str, data: dict) -> None:
        payload = {"event": event, **data}
        with self._sub_lock:
            targets = list(self._subscribers)
        for q in targets:
            q.put(payload)

    def log(self, line: str) -> None:
        self.emit("log", {"line": str(line)})

    def start(self, name: str, fn) -> bool:
        """啟動一項背景工作。已經有工作在跑就回 False，避免連按兩下跑出兩個部署。"""
        if not self._lock.acquire(blocking=False):
            return False
        self.current_job = name

        def wrapper():
            try:
                self.emit("start", {"job": name})
                result = fn(self.log)
                self.last_result = result or {}
                self.emit("done", {"job": name, "result": self.last_result})
            except FrdError as e:
                # 預期內的失敗（設定沒填、下載失敗之類），訊息本身就是給人看的
                self.log(f"[錯誤] {e}")
                self.emit("failed", {"job": name, "message": str(e)})
            except Exception as e:
                # 沒預期到的錯誤，連完整堆疊一起留在記錄區，不然無從查起
                self.log(f"[例外] {e}")
                self.log(traceback.format_exc())
                self.emit("failed", {"job": name, "message": f"未預期的錯誤：{e}"})
            finally:
                self.current_job = None
                self._lock.release()

        threading.Thread(target=wrapper, daemon=True).start()
        return True


RUNNER = JobRunner()


def read_config() -> dict:
    if not CONFIG_PATH.exists():
        return {}
    try:
        return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def write_config(updates: dict) -> dict:
    """把介面送來的欄位併回設定檔，不動介面沒管的欄位。"""
    config = read_config()
    for key in UI_MANAGED_KEYS:
        if key in updates:
            config[key] = updates[key]
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(
        json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return config


def masked_config() -> dict:
    """送給瀏覽器的設定：機密欄位一律遮罩，只回報「有沒有填」。

    介面不需要知道權杖內容，只需要知道填了沒。真的要改就整個重打，
    這樣權杖不會在網路上（就算只是 localhost）跟瀏覽器記憶體裡到處留。
    """
    config = read_config()
    unfilled = find_unfilled_fields(config)
    out = {}
    for key in UI_MANAGED_KEYS:
        value = config.get(key)
        if key in SECRET_KEYS:
            if key == "remote_admin_password":
                filled = bool(str(value or "").strip())
            else:
                filled = key not in unfilled
            out[key] = ""
            out[f"{key}_filled"] = filled
        elif key in unfilled:
            # 還沒填的欄位送空字串，不要把「【待填】...」那串佔位文字灌進輸入框
            out[key] = ""
        else:
            out[key] = value if value is not None else ""
    out["unfilled"] = unfilled
    out["package_ready"] = frd_common.FRD_EXTRACT_DIR.exists() and any(
        frd_common.FRD_EXTRACT_DIR.glob("agent.exe")
    )
    # 介面要知道鏡像有沒有設定好，沒設定就把「公司鏡像」那個選項標成不可用
    out["download_source"] = config.get("download_source") or "official"
    out["r2_configured"] = bool(str(config.get("r2_mirror_base_url", "")).strip())
    return out


def list_outputs() -> list[dict]:
    if not OUTPUT_DIR.exists():
        return []
    files = []
    for p in sorted(OUTPUT_DIR.iterdir(), key=lambda x: x.stat().st_mtime, reverse=True):
        if p.is_file():
            files.append(
                {
                    "name": p.name,
                    "size_mb": round(p.stat().st_size / 1048576, 1),
                    "time": time.strftime("%Y-%m-%d %H:%M", time.localtime(p.stat().st_mtime)),
                }
            )
    return files[:20]


class Handler(BaseHTTPRequestHandler):
    server_version = "FlexDeployUI"

    def log_message(self, fmt, *args):
        pass  # 不要把每個請求都印到主控台，記錄區才是重點

    # ── 共用小工具 ────────────────────────────────────────────
    def _token_ok(self, params: dict) -> bool:
        return secrets.compare_digest(
            (params.get("t") or [""])[0], SESSION_TOKEN
        )

    def _send_json(self, obj, status=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json_body(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if not length:
            return {}
        return json.loads(self.rfile.read(length).decode("utf-8"))

    # ── GET ───────────────────────────────────────────────────
    def do_GET(self):
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)
        path = parsed.path

        if path == "/":
            self._serve_index()
        elif path == "/api/state":
            if not self._token_ok(params):
                return self._send_json({"error": "token 不正確"}, 403)
            self._send_json(
                {
                    "config": masked_config(),
                    "running": RUNNER.current_job,
                    "outputs": list_outputs(),
                }
            )
        elif path == "/api/logs":
            if not self._token_ok(params):
                return self._send_json({"error": "token 不正確"}, 403)
            self._serve_sse()
        elif path == "/api/download":
            if not self._token_ok(params):
                return self._send_json({"error": "token 不正確"}, 403)
            self._serve_download((params.get("name") or [""])[0])
        else:
            self._send_json({"error": "找不到這個位址"}, 404)

    def _serve_index(self):
        index = UI_DIR / "index.html"
        if not index.exists():
            return self._send_json({"error": "找不到 ui/index.html"}, 500)
        body = index.read_text(encoding="utf-8").replace("__SESSION_TOKEN__", SESSION_TOKEN)
        data = body.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _serve_sse(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.end_headers()

        q = RUNNER.subscribe()
        try:
            while True:
                try:
                    payload = q.get(timeout=15)
                except queue.Empty:
                    # 心跳，避免中間的代理或瀏覽器把閒置連線收掉
                    self.wfile.write(b": keepalive\n\n")
                    self.wfile.flush()
                    continue
                line = "data: " + json.dumps(payload, ensure_ascii=False) + "\n\n"
                self.wfile.write(line.encode("utf-8"))
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            pass  # 瀏覽器關掉分頁而已，正常現象
        finally:
            RUNNER.unsubscribe(q)

    def _serve_download(self, name: str):
        # 只允許下載 output/ 底下的檔案，擋掉 ../ 這種路徑穿越
        if not name or "/" in name or "\\" in name or name.startswith("."):
            return self._send_json({"error": "檔名不合法"}, 400)
        target = (OUTPUT_DIR / name).resolve()
        if not target.is_file() or OUTPUT_DIR.resolve() not in target.parents:
            return self._send_json({"error": "找不到這個檔案"}, 404)

        ctype = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(target.stat().st_size))
        self.send_header("Content-Disposition", f'attachment; filename="{target.name}"')
        self.end_headers()
        with target.open("rb") as f:
            while chunk := f.read(1024 * 256):
                self.wfile.write(chunk)

    # ── POST ──────────────────────────────────────────────────
    def do_POST(self):
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)
        if not self._token_ok(params):
            return self._send_json({"error": "token 不正確"}, 403)

        try:
            body = self._read_json_body()
        except Exception as e:
            return self._send_json({"error": f"送來的資料不是合法 JSON：{e}"}, 400)

        path = parsed.path
        if path == "/api/config":
            write_config(body)
            self._send_json({"ok": True, "config": masked_config()})
        elif path == "/api/prepare":
            self._start_job("prepare", self._job_prepare)
        elif path == "/api/build-intune":
            self._start_job("build-intune", self._job_build_intune)
        elif path == "/api/deploy-psexec":
            devices = parse_devices(body.get("devices", ""))
            parallel = int(body.get("parallel", 5))
            if not devices:
                return self._send_json({"error": "裝置清單是空的，至少要填一台"}, 400)
            self._start_job(
                "deploy-psexec",
                lambda log: self._job_deploy(devices, parallel, log),
            )
        else:
            self._send_json({"error": "找不到這個位址"}, 404)

    def _start_job(self, name: str, fn):
        if RUNNER.start(name, fn):
            self._send_json({"ok": True, "job": name})
        else:
            self._send_json(
                {"error": f"已經有工作在跑（{RUNNER.current_job}），等它完成再試"}, 409
            )

    # ── 實際工作 ──────────────────────────────────────────────
    def _job_prepare(self, log):
        config = read_config()
        frd_common.ensure_frd_package(config, log=log)
        log("[完成] 官方套件已就緒，之後執行不必再下載")
        return {"package_ready": True}

    def _job_build_intune(self, log):
        config = frd_common.load_config(CONFIG_PATH)
        produced = run_packaging(config, log=log)
        log("")
        log("下一步（在 Intune 後台做）：")
        log("1. 應用程式 > Windows > 新增 > Win32 應用程式，上傳剛才產生的檔案")
        log("2. 安裝命令填 agent.exe（系統管理員權限執行）")
        log("3. 偵測規則填「agent.log 檔案存在」，真正的成功判斷回 Admin Console 看")
        log("4. 指派對象先選 1~2 台測試裝置")
        return {"file": produced.name}

    def _job_deploy(self, devices, parallel, log):
        config = frd_common.load_config(CONFIG_PATH)
        results = run_mass_deploy(config, devices, parallel, log=log)
        csv_path = write_summary_csv(results)
        log(f"[報告] 完整結果已寫入 {csv_path.name}")
        ok = sum(1 for r in results if r["success"])
        return {"file": csv_path.name, "success": ok, "fail": len(results) - ok}


def main():
    parser = argparse.ArgumentParser(description="ChromeOS Flex 遠端部署系統：本機網頁介面")
    parser.add_argument("--port", type=int, default=0, help="指定 port，預設自動挑一個沒用的")
    parser.add_argument("--no-browser", action="store_true", help="不要自動開瀏覽器")
    args = parser.parse_args()

    # 只綁 127.0.0.1：這台電腦以外連不進來
    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    port = server.server_address[1]
    url = f"http://127.0.0.1:{port}/?t={SESSION_TOKEN}"

    print("=" * 70)
    print("  ChromeOS Flex 遠端部署系統 - 操作介面已啟動")
    print("=" * 70)
    print(f"  網址：{url}")
    print("  這個網址含有一次性通行碼，只有這台電腦連得到，關掉視窗就失效。")
    print("  要結束服務：關掉這個視窗，或按 Ctrl+C")
    print("=" * 70)

    if not args.no_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止。")


if __name__ == "__main__":
    main()
