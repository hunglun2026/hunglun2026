﻿# ChromeOS Flex 遠端部署系統 - 介面啟動器
# 由 開始操作.bat 呼叫。檔名刻意用英文，讓 .bat 的內容能維持純 ASCII。
# 這個檔案必須存成 UTF-8 with BOM，否則 PowerShell 5.1 讀中文會整支語法錯誤。

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here

Write-Host ''
Write-Host '  ChromeOS Flex 遠端部署系統' -ForegroundColor Cyan
Write-Host '  ─────────────────────────────────────────' -ForegroundColor DarkGray

# 2026-09-11 起改用 PyInstaller 打包的執行檔，不用再裝 Python。
# exe 跟這支腳本放在同一個資料夾（build-release.ps1 打包時會一起放進去）；
# 沒有這個 exe 才退回用系統的 python 跑原始碼，方便開發時直接測試。
$exe = Join-Path $here 'flex-deploy.exe'

if (Test-Path $exe) {
    Write-Host '  正在啟動服務，瀏覽器會自動打開...' -ForegroundColor Green
    Write-Host '  要結束：關掉這個視窗，或按 Ctrl+C' -ForegroundColor DarkGray
    Write-Host ''
    & $exe
} else {
    $python = Get-Command python -ErrorAction SilentlyContinue
    if (-not $python) {
        Write-Host '  找不到 flex-deploy.exe，也沒裝 Python，兩者缺一無法啟動。' -ForegroundColor Red
        Write-Host '  請確認解壓縮後 flex-deploy.exe 跟這支腳本在同一個資料夾。' -ForegroundColor Yellow
        Write-Host ''
        Read-Host '  按 Enter 關閉'
        exit 1
    }
    Write-Host '  找不到 flex-deploy.exe，改用系統 Python 跑原始碼（開發用途）。' -ForegroundColor DarkYellow
    Write-Host ("  Python：{0}" -f $python.Source) -ForegroundColor DarkGray
    Write-Host '  正在啟動服務，瀏覽器會自動打開...' -ForegroundColor Green
    Write-Host '  要結束：關掉這個視窗，或按 Ctrl+C' -ForegroundColor DarkGray
    Write-Host ''
    python ui_server.py
}

Write-Host ''
Read-Host '  服務已結束，按 Enter 關閉'
