@echo off
chcp 65001 >nul
set PYTHONUTF8=1
cd /d "%~dp0"
if exist "%~dp0flex-deploy.exe" goto useexe
where py >nul 2>nul && goto usepy
python -X utf8 school_pack.py %*
goto done
:usepy
py -3 -X utf8 school_pack.py %*
goto done
:useexe
"%~dp0flex-deploy.exe" school-pack %*
:done
pause
