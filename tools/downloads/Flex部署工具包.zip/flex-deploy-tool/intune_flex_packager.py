"""
intune-flex-deploy 主程式
用途：把 Google ChromeOS Flex Remote Deployment (FRD) 套件，包成 Intune 能推送的
     .intunewin 檔案，並產生 agent.toml / wifi.onc 這兩個 FRD 真正吃的設定檔。

2026-09-10 已依官方快速入門指南（support.google.com/chromeosflex/answer/16390566）
與參考資料頁（/answer/16387032）核對過真實格式：
- FRD 套件公開直接下載，不需要審核等待：https://dl.google.com/cros-frd/frd-latest.zip
- 主執行檔是 agent.exe（不是原本猜測的 setup.exe）
- 設定檔是一個 TOML 檔（agent.toml），欄位包含 enrollment_token / onc_file / dry_run 等
- Wi-Fi 設定另外放在 ONC 格式的 JSON 檔案裡，agent.toml 用 onc_file 欄位指過去

用法：
    python intune_flex_packager.py --config secrets\\config.json

secrets\\config.json 格式見 secrets\\config.example.json（複製一份改成 config.json，
不要把真的 token/密碼直接打在指令列上，會留在 shell 歷史紀錄裡）。
"""

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

from frd_common import (
    PROJECT_DIR,
    FrdError,
    build_config_files,
    download_file,
    load_config,
    resolve_frd_source_dir,
)

TOOLS_DIR = PROJECT_DIR / "tools"
OUTPUT_DIR = PROJECT_DIR / "output"

# 官方 Win32 App 打包工具（2026-08 確認：舊的 Intune-Win32-App-Packaging-Tool repo 已停用，
# 現在的正式來源是 Microsoft-Win32-Content-Prep-Tool）
INTUNEWINAPPUTIL_URL = (
    "https://raw.githubusercontent.com/microsoft/"
    "Microsoft-Win32-Content-Prep-Tool/master/IntuneWinAppUtil.exe"
)
INTUNEWINAPPUTIL_PATH = TOOLS_DIR / "IntuneWinAppUtil.exe"

# Intune 的安裝命令跑這支腳本，不直接跑 agent.exe：腳本先檢查硬體、先模擬再正式，
# 並用結束代碼讓 Intune 後台看得出每台的結果（代碼表寫在腳本開頭）
INSTALL_SCRIPT = PROJECT_DIR / "intune-install.ps1"

INTUNE_NEXT_STEPS = [
    "1. Intune 系統管理中心 > 應用程式 > Windows > 新增 > Windows 應用程式 (Win32)，上傳 output 底下的 .intunewin",
    "2. 安裝命令：%SystemRoot%\\Sysnative\\WindowsPowerShell\\v1.0\\powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\\intune-install.ps1",
    "   （Microsoft 官方：直接寫 powershell.exe 會用 32 位元執行）",
    "   安裝所需時間：120 分鐘；安裝行為：系統；裝置重新啟動行為：依據傳回碼決定行為",
    "3. 傳回碼：保留預設（1641＝正式轉換已開始、強制重開機；1618＝沒插電、重試），其他代碼看 intune-install.ps1 開頭的代碼表",
    "4. 偵測規則：檔案，路徑 %ProgramData%\\frd-deploy，",
    "   模擬版（dry_run = true）填 dryrun-ok.txt；正式版（dry_run = false）填 install-started.txt",
    "5. 先指派模擬版給試點群組，後台全部顯示「已安裝」再指派正式版；正式轉換成功與否看 Google 管理控制台",
    "   （agent.exe 會自己重開機，正式版在 Intune 停在「安裝中」是正常的）",
    "6. 部署前先在一台 ChromeOS 裝置的 chrome://network 匯入 wifi.onc 測過（Google 官方：FRD 不檢查 ONC，寫錯就全部註冊失敗）",
]


def ensure_intunewinapputil(log=print) -> Path:
    """第一次執行自動下載官方打包工具，之後重複使用同一份。"""
    if INTUNEWINAPPUTIL_PATH.exists():
        return INTUNEWINAPPUTIL_PATH

    log("[下載] IntuneWinAppUtil.exe 尚未取得，從官方 GitHub 下載...")
    TOOLS_DIR.mkdir(parents=True, exist_ok=True)
    try:
        download_file(INTUNEWINAPPUTIL_URL, INTUNEWINAPPUTIL_PATH, log=log)
    except Exception as e:
        raise FrdError(
            f"下載 IntuneWinAppUtil.exe 失敗：{e}\n"
            f"可以手動從 https://github.com/microsoft/Microsoft-Win32-Content-Prep-Tool "
            f"下載後放到 {INTUNEWINAPPUTIL_PATH}"
        )
    log(f"[完成] 已存到 {INTUNEWINAPPUTIL_PATH}")
    return INTUNEWINAPPUTIL_PATH


def package_intunewin(source_dir: Path, setup_file: str, output_dir: Path, log=print) -> Path:
    """呼叫官方工具把 source_dir 打包成 .intunewin。"""
    exe = ensure_intunewinapputil(log=log)
    output_dir.mkdir(parents=True, exist_ok=True)

    setup_path = source_dir / setup_file
    if not setup_path.exists():
        raise FrdError(
            f"找不到主執行檔：{setup_path}\n"
            f"確認 frd_source_dir 裡有這個檔案，或改 --setup-file 參數。"
        )

    cmd = [
        str(exe),
        "-c", str(source_dir),
        "-s", setup_file,
        "-o", str(output_dir),
        "-q",  # 靜默模式，不跳互動視窗
    ]
    log("[執行] 正在打包成 .intunewin（約 1 GB，需要幾分鐘）...")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise FrdError(f"打包失敗：\n{result.stdout}\n{result.stderr}")

    intunewin_files = list(output_dir.glob("*.intunewin"))
    if not intunewin_files:
        raise FrdError("打包指令跑完了，但沒找到 .intunewin 輸出檔，去看上面的訊息排查。")

    produced = intunewin_files[0]
    size_mb = produced.stat().st_size // 1048576
    log(f"[完成] 產出 {produced.name}（{size_mb} MB）")
    return produced


def run_packaging(config: dict, setup_file: str = "intune-install.ps1", log=print) -> Path:
    """完整的 Intune 打包流程。命令列與網頁介面共用這個函式。"""
    frd_source_dir = resolve_frd_source_dir(config, log=log)
    # 設定檔（agent.toml / wifi.onc）跟 FRD 主程式放在同一個來源資料夾，
    # 這樣打包時會一起收進 .intunewin
    build_config_files(config, frd_source_dir, log=log)
    shutil.copy2(INSTALL_SCRIPT, frd_source_dir / INSTALL_SCRIPT.name)
    return package_intunewin(frd_source_dir, setup_file, OUTPUT_DIR, log=log)


def main():
    parser = argparse.ArgumentParser(description="包出可推送到 Intune 的 ChromeOS Flex 部署套件")
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_DIR / "secrets" / "config.json",
        help="設定檔路徑（預設 secrets\\config.json）",
    )
    parser.add_argument(
        "--setup-file",
        default="intune-install.ps1",
        help="打包時記錄的安裝檔名（預設是我們的安裝腳本，它會去執行 agent.exe）",
    )
    args = parser.parse_args()

    try:
        config = load_config(args.config)
        run_packaging(config, args.setup_file)
    except FrdError as e:
        sys.exit(str(e))

    print("\n下一步（在 Intune 後台做）：")
    for line in INTUNE_NEXT_STEPS:
        print(line)


if __name__ == "__main__":
    main()
