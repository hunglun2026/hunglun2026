@echo off
chcp 65001 >nul
set PWSH=pwsh
if exist "C:\Program Files\PowerShell\7\pwsh.exe" set PWSH=C:\Program Files\PowerShell\7\pwsh.exe
"%PWSH%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0start-ui.ps1"
