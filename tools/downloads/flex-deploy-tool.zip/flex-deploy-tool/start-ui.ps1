﻿# ChromeOS Flex 遠端部署系統 - 介面啟動器
# 由 啟動介面.bat 呼叫。檔名刻意用英文，讓 .bat 的內容能維持純 ASCII。
# 這個檔案必須存成 UTF-8 with BOM，否則 PowerShell 5.1 讀中文會整支語法錯誤。

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here

Write-Host ''
Write-Host '  ChromeOS Flex 遠端部署系統' -ForegroundColor Cyan
Write-Host '  ─────────────────────────────────────────' -ForegroundColor DarkGray

# 檢查 Python 在不在
$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) {
    Write-Host '  找不到 Python。' -ForegroundColor Red
    Write-Host '  請先安裝 Python 3（https://www.python.org/downloads/），' -ForegroundColor Yellow
    Write-Host '  安裝時記得勾選「Add Python to PATH」，裝完重開這個視窗再試。' -ForegroundColor Yellow
    Write-Host ''
    Read-Host '  按 Enter 關閉'
    exit 1
}

Write-Host ("  Python：{0}" -f $python.Source) -ForegroundColor DarkGray
Write-Host '  正在啟動服務，瀏覽器會自動打開...' -ForegroundColor Green
Write-Host '  要結束：關掉這個視窗，或按 Ctrl+C' -ForegroundColor DarkGray
Write-Host ''

# ui_server.py 預設會自己挑一個沒被佔用的 port，所以不必在這裡判斷 port 衝突，
# 兩個人同時開也不會互相搶。
python ui_server.py

Write-Host ''
Read-Host '  服務已結束，按 Enter 關閉'
